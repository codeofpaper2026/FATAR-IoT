# Contributing

Run `python -m pytest -q` and the synthetic smoke configuration before contributing.
Add a test for every bug fix. Changes to preprocessing, numerical conventions,
random-stream IDs, aggregation, stopping rules or configuration defaults must be
recorded in the documentation because they may change scientific results.

Never paste manuscript table values into generated outputs, suppress unfavorable
runs, relabel newly generated samples as original data, or use test labels to choose
hyperparameters. Keep dataset versions, sources, usage terms, row assignments and
run seeds explicit. Do not rename `geometry_trust` to the original `TrustFedAvg`
without independently recovering and verifying that implementation.

Do not commit credentials, caches, virtual environments, live traffic or unreviewed
third-party data. Maintain separate code and dataset licensing notices. Replace any
archival/repository metadata only with genuine identifiers after publication.
