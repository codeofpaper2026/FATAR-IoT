from pathlib import Path
import pytest
from fatr_iot.config import DataConfig, ExperimentConfig
from fatr_iot.data import synthetic_dataset, load_raw, prepare_data

@pytest.fixture
def tiny_source(tmp_path):
    return synthetic_dataset(tmp_path / "raw", samples=1500, seed=101)

@pytest.fixture
def tiny_config(tiny_source):
    cfg = ExperimentConfig()
    cfg.data = DataConfig(source=str(tiny_source), reference_size=60, calibration_size=60)
    cfg.federation.clients = 8
    cfg.federation.rounds = 2
    cfg.federation.minimum_client_size = 5
    cfg.methods = ["fedavg", "median", "trimmed_mean", "krum", "geometry_trust", "fatr",
                   "fatr_no_drift", "fatr_no_history", "fatr_no_clipping", "fatr_no_smoothing"]
    cfg.attacks = ["none", "sign_flip", "gaussian", "label_flip", "scaling"]
    cfg.seeds = [7]
    return cfg

@pytest.fixture
def tiny_data(tiny_config):
    raw = load_raw(tiny_config.data, Path("."))
    return prepare_data(raw, tiny_config.data, 7)
