from dataclasses import replace
from pathlib import Path
import io
import zipfile
import numpy as np
import pandas as pd
import pytest
from numpy.testing import assert_allclose
from fatr_iot.config import DataConfig
from fatr_iot.data import SPLITS, Preprocessor, load_raw, prepare_data, synthetic_dataset
from fatr_iot.download import fetch_rt_iot2022
from fatr_iot.partition import dirichlet_partition
from fatr_iot.utils import rng_for, sha256_file


def test_synthetic_generation_is_reproducible(tmp_path):
    a = synthetic_dataset(tmp_path / "a", 1000, 3)
    b = synthetic_dataset(tmp_path / "b", 1000, 3)
    assert sha256_file(a) == sha256_file(b)


def test_preprocessing_is_fit_on_training_only():
    train = pd.DataFrame({"number": [0., 2., np.nan], "category": ["a", "b", "a"]})
    test = pd.DataFrame({"number": [1000.], "category": ["never_seen"]})
    prep = Preprocessor().fit(train)
    before = str(prep.state)
    encoded = prep.transform(test)
    assert str(prep.state) == before
    assert prep.state["medians"] == [1.0] and prep.state["means"] == [1.0]
    assert_allclose(encoded[0, 1:], 0)


def test_all_missing_column_and_log_transform():
    train = pd.DataFrame({"x": [np.nan, np.inf], "z": [-1., 3.]})
    encoded = Preprocessor(signed_log1p=True, scaled_clip=2).fit(train).transform(train)
    assert np.isfinite(encoded).all()
    assert np.max(np.abs(encoded)) <= 2


def test_disjoint_splits_and_benign_buffers(tiny_data):
    for i, left in enumerate(SPLITS):
        for right in SPLITS[i + 1:]:
            assert not set(tiny_data.arrays[f"{left}_ids"]) & set(tiny_data.arrays[f"{right}_ids"])
    assert set(tiny_data.arrays["reference_y"]) == {0}
    assert set(tiny_data.arrays["calibration_y"]) == {0}
    assert tiny_data.preprocessor["fit_rows"] == len(tiny_data.arrays["train_y"])


def test_same_seed_gives_identical_splits(tiny_config):
    raw = load_raw(tiny_config.data, Path("."))
    a = prepare_data(raw, tiny_config.data, 4); b = prepare_data(raw, tiny_config.data, 4)
    for key in a.arrays:
        assert np.array_equal(a.arrays[key], b.arrays[key])


def test_explicit_shared_buffer(tiny_config):
    cfg = replace(tiny_config.data, shared_reference_calibration=True)
    raw = load_raw(cfg, Path(".")); prepared = prepare_data(raw, cfg, 4)
    assert np.array_equal(prepared.arrays["reference_ids"], prepared.arrays["calibration_ids"])
    assert prepared.manifest["cross_split_feature_hash_overlaps"]["reference:calibration"] == cfg.reference_size


def test_npz_has_no_pickled_arrays(tiny_data, tmp_path):
    tiny_data.save(tmp_path / "prepared")
    with np.load(tmp_path / "prepared/dataset.npz", allow_pickle=False) as bundle:
        for key in bundle:
            assert bundle[key].dtype != object


def test_partition_coverage_and_reproducibility():
    y = np.array([0] * 900 + [1] * 100)
    parts, info = dirichlet_partition(y, 10, .5, 5, 1000, rng_for(8))
    other, _ = dirichlet_partition(y, 10, .5, 5, 1000, rng_for(8))
    assert sorted(np.concatenate(parts).tolist()) == list(range(1000))
    assert all(len(p) >= 5 for p in parts)
    assert all(np.array_equal(p, q) for p, q in zip(parts, other))
    assert info["attempts"] >= 1


def test_partition_impossible_fails():
    with pytest.raises(ValueError):
        dirichlet_partition(np.zeros(10), 10, .5, 5, 10, rng_for(1))


def test_rt_loader_fixture_mapping_and_id_drop(tmp_path):
    # Small invented schema fixture, NOT downloaded RT-IoT2022 observations.
    path = tmp_path / "rt.csv"
    pd.DataFrame({"Unnamed: 0": [0, 1, 2, 3], "proto": ["tcp"] * 4,
                  "service": ["mqtt"] * 4, "rate": [1., 2., 3., 4.],
                  "Attack_type": ["MQTT_Publish", "Thing_Speak", "DOS_SYN_Hping", "ARP_poisioning"]}).to_csv(path, index=False)
    raw = load_raw(DataConfig(dataset="rt_iot2022", source=str(path)), tmp_path)
    assert raw.y.tolist() == [0, 0, 1, 1]
    assert "Unnamed: 0" not in raw.X and "Attack_type" not in raw.X
    frame = pd.read_csv(path); frame.loc[0, "Attack_type"] = "unverified_new_type"; frame.to_csv(path, index=False)
    with pytest.raises(ValueError, match="Unrecognized"):
        load_raw(DataConfig(dataset="rt_iot2022", source=str(path)), tmp_path)


def test_unsw_official_test_membership_and_duplicates(tmp_path):
    rng = rng_for(12)
    n = 500
    frame = pd.DataFrame({"id": np.arange(n), "x": rng.normal(size=n), "proto": ["tcp"] * n,
                          "label": np.tile([0, 1], n // 2), "attack_cat": np.tile(["Normal", "Generic"], n // 2)})
    train = tmp_path / "train.csv"; test = tmp_path / "test.csv"
    frame.iloc[:400].to_csv(train, index=False)
    # Include a training duplicate in test; it must be removed, not leaked.
    conflicting = frame.iloc[[0]].copy()
    conflicting["label"] = 1
    conflicting["attack_cat"] = "Generic"
    pd.concat([frame.iloc[400:], conflicting]).to_csv(test, index=False)
    cfg = DataConfig(dataset="unsw_nb15", source=str(train), testing_source=str(test), reference_size=20, calibration_size=20)
    raw = load_raw(cfg, tmp_path); prepared = prepare_data(raw, cfg, 42)
    assert len(prepared.arrays["test_y"]) == 100
    assert prepared.manifest["conflicting_feature_rows_observed"] == 2
    assert prepared.manifest["total_rows_removed"] == 1
    assert all(str(x).startswith("test-") for x in prepared.arrays["test_ids"])
    assert all(str(x).startswith("train-") for x in prepared.arrays["train_ids"])
    assert "id" not in raw.X and "attack_cat" not in raw.X


def test_downloader_local_fixture_is_path_safe(tmp_path):
    archive = tmp_path / "fixture.zip"
    with zipfile.ZipFile(archive, "w") as z:
        z.writestr("../../RT_IOT2022.csv", "x,Attack_type\n1,MQTT_Publish\n2,DOS_SYN_Hping\n")
    destination = fetch_rt_iot2022(tmp_path / "out", sha256_file(archive), archive)
    assert destination == tmp_path / "out/RT_IOT2022.csv"
    assert destination.is_file()
    assert not (tmp_path / "RT_IOT2022.csv").exists()
    with pytest.raises(ValueError, match="SHA256"):
        fetch_rt_iot2022(tmp_path / "mismatch", "0" * 64, archive)
