from dataclasses import replace
import numpy as np
import pytest
from numpy.testing import assert_allclose
from fatr_iot.aggregation import Aggregator, clip_updates, cosine_rows, krum
from fatr_iot.attacks import attack_active, poison_labels, poison_update
from fatr_iot.config import AttackConfig, BaselineConfig, ExperimentConfig, FATRConfig, METHODS, load_config
from fatr_iot.metrics import binary_metrics, calibrate_threshold
from fatr_iot.model import gradient, logistic_loss, local_update
from fatr_iot.utils import rng_for


def make_aggregator(method, n=5, p=3, config=None):
    return Aggregator(method, n, p, config or FATRConfig(), BaselineConfig(), 1)


def test_gradient_matches_finite_difference():
    rng = rng_for(1)
    X = rng.normal(size=(30, 4)); y = rng.integers(0, 2, size=30); theta = rng.normal(size=5)
    exact = gradient(theta, X, y, 0.1)
    estimate = np.zeros(5)
    for i in range(5):
        move = np.zeros(5); move[i] = 1e-6
        estimate[i] = (logistic_loss(theta + move, X, y, 0.1) - logistic_loss(theta - move, X, y, 0.1)) / 2e-6
    assert_allclose(exact, estimate, atol=1e-8)


def test_sigmoid_loss_extremes_are_finite():
    assert np.isfinite(logistic_loss(np.array([1000., -1000.]), np.array([[1.], [-1.]]), np.array([0, 1])))


@pytest.mark.parametrize("target", [0.0, 0.01, 0.05, 0.25, 0.9])
def test_empirical_calibration_bound_and_ties(target):
    scores = np.round(rng_for(2).uniform(size=997), 2)
    threshold = calibrate_threshold(scores, target)
    assert np.mean(scores > threshold) <= target + 1e-12
    assert np.isfinite(threshold)


def test_equal_calibration_scores_predict_no_attacks():
    assert calibrate_threshold(np.ones(100) * .5, .05) == .5


@pytest.mark.parametrize("scores,target", [(np.array([]), .05), (np.array([np.nan]), .05), (np.array([.1]), 1.0)])
def test_invalid_calibration_rejected(scores, target):
    with pytest.raises(ValueError):
        calibrate_threshold(scores, target)


def test_binary_metrics_match_known_counts():
    y = np.array([0, 0, 0, 1, 1]); scores = np.array([.1, .2, .9, .8, .2])
    result = binary_metrics(y, scores, .5)
    assert (result["tn"], result["fp"], result["fn"], result["tp"]) == (2, 1, 1, 1)
    assert result["f1"] == .5
    assert_allclose(result["fpr"], 1 / 3)


def test_undefined_metric_is_missing_not_fake_zero():
    result = binary_metrics(np.array([0, 0]), np.array([.1, .2]), .5)
    assert result["auc"] is None and result["precision"] is None and result["mcc"] is None


def test_fedavg_is_sample_weighted():
    U = np.array([[1., 2., 0.], [3., 4., 1.]])
    result, _ = make_aggregator("fedavg", 2).aggregate(U, np.array([1, 3]), np.zeros(3), np.zeros((4, 2)))
    assert_allclose(result, np.average(U, axis=0, weights=[1, 3]))


def test_coordinate_median_even_convention():
    U = np.array([[0., 8., 2.], [4., 2., 0.]])
    result, _ = make_aggregator("median", 2).aggregate(U, np.ones(2), np.zeros(3), np.zeros((2, 2)))
    assert_allclose(result, [2., 5., 1.])


def test_trimmed_mean_removes_each_tail():
    U = np.repeat(np.array([-100., 1., 2., 3., 100.])[:, None], 3, axis=1)
    result, _ = make_aggregator("trimmed_mean").aggregate(U, np.ones(5), np.zeros(3), np.zeros((2, 2)))
    assert_allclose(result, np.full(3, 2.0))


def test_krum_ignores_far_outlier():
    U = np.array([[1., 1.], [1., 1.], [1., 1.], [1., 1.], [100., -100.]])
    assert_allclose(krum(U, 1), [1., 1.])
    with pytest.raises(ValueError):
        krum(U[:4], 1)


def test_norm_clipping_cap():
    U = np.array([[1., 0.], [2., 0.], [3., 0.], [4., 0.], [100., 0.]])
    clipped, info = clip_updates(U, 2.5, 1e-12)
    assert np.max(np.linalg.norm(clipped, axis=1)) <= info["clip_cap"] + 1e-12
    zeros, _ = clip_updates(np.zeros((5, 2)), 2.5, 1e-12)
    assert_allclose(zeros, 0)


def test_zero_vector_cosine_is_zero():
    assert_allclose(cosine_rows(np.zeros((3, 2)), np.ones(2), 1e-12), 0)
    assert_allclose(cosine_rows(np.ones((3, 2)), np.zeros(2), 1e-12), 0)


@pytest.mark.parametrize("method", METHODS)
def test_zero_updates_are_safe(method):
    aggregator = make_aggregator(method)
    result, info = aggregator.aggregate(np.zeros((5, 3)), np.ones(5), np.zeros(3), np.zeros((10, 2)))
    assert_allclose(result, 0)
    assert np.isfinite(aggregator.trust).all()


@pytest.mark.parametrize("method", METHODS)
def test_nonfinite_updates_are_excluded(method):
    U = np.ones((5, 3)); U[0, 0] = np.nan; U[1, 0] = np.inf
    result, info = make_aggregator(method).aggregate(U, np.ones(5), np.zeros(3), np.zeros((10, 2)))
    assert info["valid"].tolist() == [False, False, True, True, True]
    assert np.isfinite(result).all()


def test_all_invalid_no_update():
    result, info = make_aggregator("fatr").aggregate(np.full((5, 3), np.nan), np.ones(5), np.zeros(3), np.zeros((10, 2)))
    assert_allclose(result, 0)
    assert info["fallback"] == "all_invalid_no_update"


def test_history_gate_and_trust_formula():
    cfg = FATRConfig(alpha=0, beta=0, gamma=0, drift_lambda=0, norm_mu=0, trust_ema=.8, initial_trust=.25)
    aggregator = make_aggregator("fatr", config=cfg)
    _, info = aggregator.aggregate(np.ones((5, 3)), np.ones(5), np.zeros(3), np.zeros((10, 2)))
    assert_allclose(info["trust"], .8 * .25 + .2 * .5)
    assert_allclose(aggregator.history, 0)
    cfg = replace(cfg, beta=1, initial_trust=1, history_gate=.5)
    aggregator = make_aggregator("fatr", config=cfg)
    aggregator.aggregate(np.ones((5, 3)), np.ones(5), np.zeros(3), np.zeros((10, 2)))
    assert_allclose(aggregator.history, np.ones((5, 3)) * (1 - cfg.history_ema))


def test_no_drift_does_not_use_reference():
    U = rng_for(3).normal(size=(5, 3))
    a, _ = make_aggregator("fatr_no_drift").aggregate(U, np.ones(5), np.zeros(3), np.zeros((10, 2)))
    b, _ = make_aggregator("fatr_no_drift").aggregate(U, np.ones(5), np.zeros(3), np.full((10, 2), np.nan))
    assert_allclose(a, b)


def test_zero_weight_fallback():
    cfg = FATRConfig(alpha=0, beta=0, gamma=1e6, drift_lambda=0, norm_mu=0, trust_ema=0, clipping=False)
    U = np.array([[1., 0., 0.], [0., 1., 0.], [-1., 0., 0.], [0., -1., 0.]])
    result, info = make_aggregator("fatr", n=4, config=cfg).aggregate(U, np.ones(4), np.zeros(3), np.zeros((3, 2)))
    assert info["fallback"] == "zero_weight_coordinate_median"
    assert_allclose(result, np.median(U, axis=0))


def test_attack_formulas_and_no_mutation():
    cfg = AttackConfig(); delta = np.array([1., 2.]); original = delta.copy()
    assert_allclose(poison_update(delta, "sign_flip", cfg, rng_for(1)), -5 * delta)
    assert_allclose(poison_update(delta, "scaling", cfg, rng_for(1)), 10 * delta)
    assert_allclose(delta, original)
    labels = np.array([0, 0, 1, 1])
    assert_allclose(poison_labels(labels, 1, rng_for(1)), 1 - labels)
    assert_allclose(labels, [0, 0, 1, 1])
    cfg.start_round, cfg.end_round = 3, 5
    assert not attack_active(2, cfg) and attack_active(3, cfg) and not attack_active(6, cfg)


def test_rng_method_order_independence():
    assert_allclose(rng_for(42, 50, 3, 7).normal(size=10), rng_for(42, 50, 3, 7).normal(size=10))


def test_config_rejects_unknown_fields_and_cycles(tmp_path):
    path = tmp_path / "bad.yaml"; path.write_text("fatr:\n  typo: 1\n")
    with pytest.raises(ValueError):
        load_config(path)
    path.write_text("extends: bad.yaml\n")
    with pytest.raises(ValueError):
        load_config(path)


@pytest.mark.parametrize("mutate", [
    lambda c: setattr(c.federation, "rounds", 0),
    lambda c: setattr(c.attack, "byzantine_fraction", .7),
    lambda c: setattr(c.fatr, "trust_ema", 1),
    lambda c: setattr(c, "seeds", [1, 1]),
    lambda c: setattr(c, "methods", ["TrustFedAvg"]),
])
def test_config_validation(mutate):
    cfg = ExperimentConfig(); mutate(cfg)
    with pytest.raises(ValueError):
        cfg.validate()


def test_composite_score_matches_manual_equations():
    from scipy.special import expit
    from fatr_iot.model import probability
    cfg = FATRConfig()
    U = rng_for(91).normal(0, .15, size=(5, 3))
    X = rng_for(92).normal(size=(25, 2))
    theta = np.array([.1, -.2, .05])
    aggregator = make_aggregator("fatr", config=cfg)
    V, clip = clip_updates(U, cfg.clipping_k, cfg.epsilon)
    center = np.median(V, axis=0)
    distances = np.linalg.norm(V-center, axis=1)
    normalized = np.minimum(distances/max(float(np.median(distances)), cfg.epsilon), cfg.max_normalized_distance)
    D = np.array([np.mean(probability(theta+v, X)-probability(theta, X)) for v in V])
    z = np.clip((D-np.median(D))/max(cfg.drift_mad_factor*np.median(np.abs(D-np.median(D))),cfg.drift_scale_floor), -cfg.max_abs_drift_z,cfg.max_abs_drift_z)
    phi = np.clip(clip['raw_norms']/max(clip['median_norm'],cfg.epsilon)-1,0,cfg.max_norm_penalty)
    score = cfg.alpha*cosine_rows(V,center,cfg.epsilon)-cfg.gamma*normalized-cfg.drift_lambda*np.abs(z)-cfg.norm_mu*phi
    trust = cfg.trust_ema*cfg.initial_trust+(1-cfg.trust_ema)*expit(score)
    sizes = np.array([5,10,20,40,80])
    result, info = aggregator.aggregate(U,sizes,theta,X)
    assert_allclose(info['score'],score,atol=1e-12)
    assert_allclose(info['drift'],D,atol=1e-12)
    assert_allclose(info['trust'],trust,atol=1e-12)
    assert_allclose(result,np.average(V,axis=0,weights=trust*sizes),atol=1e-12)
