from pathlib import Path
import json
import numpy as np
import pandas as pd
import pytest
from numpy.testing import assert_allclose
from fatr_iot.analysis import summarize
from fatr_iot.cli import main
from fatr_iot.experiment import run_campaign


def test_every_method_and_attack_executes(tiny_config, tmp_path):
    output = tmp_path / "all"
    report = run_campaign(tiny_config, Path("."), output)
    assert report["runs"] == 50
    assert not report["original_manuscript_metrics_reproduced"]
    summary = summarize(output, 100)
    assert summary["runs"] == 50
    frame = pd.read_csv(output / "summary.csv")
    assert frame.f1_sample_sd.isna().all()  # One seed cannot yield sample SD.
    assert (frame.n_runs == 1).all()
    for path in output.glob("seed_*/*/*/round_metrics.csv"):
        table = pd.read_csv(path)
        assert (table.calibration_fpr <= tiny_config.target_fpr + 1e-12).all()
    with pytest.raises(FileExistsError):
        run_campaign(tiny_config, Path("."), output)


def test_results_independent_of_method_order(tiny_config, tmp_path):
    tiny_config.methods = ["fatr", "fedavg"]; tiny_config.attacks = ["sign_flip"]
    run_campaign(tiny_config, Path("."), tmp_path / "a")
    tiny_config.methods.reverse()
    run_campaign(tiny_config, Path("."), tmp_path / "b")
    for method in tiny_config.methods:
        with np.load(tmp_path / f"a/seed_7/sign_flip/{method}/model.npz") as a, np.load(tmp_path / f"b/seed_7/sign_flip/{method}/model.npz") as b:
            assert_allclose(a["theta"], b["theta"], atol=0, rtol=0)
            assert a["threshold"] == b["threshold"]


def test_between_seed_summary_and_prediction_reload(tiny_config, tmp_path):
    tiny_config.methods = ["fatr", "median"]; tiny_config.attacks = ["sign_flip"]; tiny_config.seeds = [1, 2]
    out = tmp_path / "pair"
    run_campaign(tiny_config, Path("."), out)
    summarize(out, 100)
    frame = pd.read_csv(out / "summary.csv")
    assert (frame.n_runs == 2).all() and frame.f1_sample_sd.notna().all()
    assert (out / "paired_differences.csv").is_file()
    model_dir = out / "seed_1/sign_flip/fatr"
    scores_file = tmp_path / "predicted.csv"
    assert main(["predict", "--model-dir", str(model_dir), "--csv", tiny_config.data.source, "--output", str(scores_file)]) == 0
    scores = pd.read_csv(scores_file).set_index("row_id")
    reported = pd.read_csv(model_dir / "test_predictions.csv.gz").set_index("row_id")
    assert_allclose(scores.loc[reported.index, "attack_probability"], reported.attack_probability, atol=1e-12)
