# Prepared synthetic example: seed 42

This directory is a new example split, not original manuscript data.

- `dataset.npz`: numeric arrays, labels, row IDs, original group strings and feature names.
- `split_ids.csv`: one row per split membership.
- `preprocessor.json`: training-only imputation, scaling and categorical state.
- `manifest.json`: provenance, observed counts, feature overlap checks and SHA-256.

Load NPZ with `allow_pickle=False`. The five split names are `train`, `validation`,
`reference`, `calibration` and `test`; array names use `<split>_X`, `<split>_y`,
`<split>_ids` and `<split>_groups`. Reference and calibration contain benign rows only.
The included data card and `docs/DATASETS.md` describe the preparation sequence.

Recreate at a fresh output path using:

```bash
python -m fatr_iot prepare --config configs/synthetic.yaml --seed 42 --output outputs/prepared_seed42
```
