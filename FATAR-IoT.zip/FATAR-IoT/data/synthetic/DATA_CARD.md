# Synthetic v1 data card

**Status:** newly generated generic binary classification data; not observed IoT
traffic and not the dataset that generated the original paper's reported results.

Purpose: offline verification and controlled algorithm experiments. No person,
network customer, institution or real device is represented by a row. Feature names
are `x00` through `x19`; none is a real protocol field. Labels are benign=0/attack=1.
`row_id` is solely an identifier and is excluded from the model.

The manifest records exact `make_classification` arguments, seed, versions, label
counts and SHA-256. The raw CSV is gzip-compressed with a fixed timestamp and uses
17 significant digits. A prepared, training-only-transformed example is included
in `data/example_split`; the raw CSV is the authoritative generator output.

The nominal class weights are 0.85/0.15 and label-noise probability is 0.02.
Observed counts need not equal those weights. Correlated/redundant features and
classification boundaries come from a generic mathematical generator rather than
packet captures. The data do not validate production prevalence, timing, resource
cost, real traffic drift, unseen attack families or network-derived feature semantics.

License: MIT for this newly generated artifact. The generator library retains its
own license. Public datasets mentioned elsewhere retain their separate licenses.
