# RT-IoT2022: bundled original observations

`RT_IOT2022.csv` contains all 123,117 original observations. Bytes are unchanged from the official UCI archive. `download_manifest.json` records the observed CSV/archive SHA-256 hashes, official source and attribution. The CSV hash is 956956c09c1764584fa08acd0f6876475626bcedcd6a6b1f8c492c2e9a2089ea.

Attribution: S., B. & Nagapadma, R. (2023). RT-IoT2022 [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5P338.
License: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/.
Source: https://archive.ics.uci.edu/dataset/942/rt-iot2022.

These are testbed captures with controlled network attacks, not production deployment traces. Training preparation deduplicates and transforms the observations as described in docs/DATASETS.md; the included source CSV is unmodified.

Run from the extracted project root:
`python -m fatr_iot run --config configs/rt_iot2022.yaml --output outputs/rt_iot2022 --plots`

If the CSV is absent, fetch it with:
`python -m fatr_iot fetch rt_iot2022 --output data/raw/rt_iot2022`
The downloader refuses to overwrite existing observations.
