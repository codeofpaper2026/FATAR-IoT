# UNSW-NB15 raw data destination

No original observations are bundled. Obtain the custodian's predefined CSVs from
https://research.unsw.edu.au/projects/unsw-nb15-dataset and place them here as:

`UNSW_NB15_training-set.csv` and `UNSW_NB15_testing-set.csv`.

Use the original files, not an undocumented mirror or resampled third-party variant.
Read the custodian's terms, including citation and commercial-use conditions.
The root MIT license does not apply to these original dataset files.

Run `python -m fatr_iot prepare --config configs/unsw_nb15.yaml --seed 42 --output outputs/unsw_prepared`
from the repository root to record input hashes and prepare disjoint arrays.
