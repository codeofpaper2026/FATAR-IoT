"""Strict, fully recorded reference settings. None are recovered paper defaults."""
from __future__ import annotations
from dataclasses import asdict, dataclass, field
from pathlib import Path
import math
import yaml

METHODS = (
    "fedavg", "median", "trimmed_mean", "krum", "geometry_trust", "fatr",
    "fatr_no_drift", "fatr_no_history", "fatr_no_clipping", "fatr_no_smoothing",
)
ATTACKS = ("none", "sign_flip", "gaussian", "label_flip", "scaling")

@dataclass
class DataConfig:
    dataset: str = "synthetic"
    source: str = "../data/synthetic/synthetic_v1.csv.gz"
    testing_source: str | None = None
    test_fraction: float = 0.2
    reference_size: int = 1200
    calibration_size: int = 1200
    shared_reference_calibration: bool = False
    validation_fraction: float = 0.1
    deduplicate: bool = True
    signed_log1p: bool = False
    scaled_clip: float | None = None

@dataclass
class FederationConfig:
    clients: int = 20
    rounds: int = 30
    dirichlet_alpha: float = 0.5
    minimum_client_size: int = 10
    partition_retries: int = 1000
    local_epochs: int = 1
    batch_size: int = 64
    learning_rate: float = 0.05
    l2: float = 0.0001
    server_learning_rate: float = 1.0
    feature_scale_std: float = 0.0
    feature_bias_std: float = 0.0
    feature_noise_std: float = 0.0

@dataclass
class FATRConfig:
    alpha: float = 2.0
    beta: float = 1.0
    gamma: float = 1.0
    drift_lambda: float = 1.0
    norm_mu: float = 0.5
    trust_ema: float = 0.8
    initial_trust: float = 0.5
    clipping_k: float = 2.5
    history_ema: float = 0.8
    history_gate: float = 0.5
    epsilon: float = 1e-12
    drift_scale_floor: float = 1e-6
    drift_mad_factor: float = 1.4826
    max_abs_drift_z: float = 10.0
    max_normalized_distance: float = 100.0
    max_norm_penalty: float = 100.0
    clipping: bool = True

@dataclass
class AttackConfig:
    byzantine_fraction: float = 0.2
    start_round: int = 1
    end_round: int | None = None
    sign_flip_scale: float = 5.0
    gaussian_relative_std: float = 2.0
    scaling_multiplier: float = 10.0
    label_flip_fraction: float = 1.0

@dataclass
class BaselineConfig:
    trim_fraction: float = 0.2
    krum_byzantine_bound: int | None = None

@dataclass
class ExperimentConfig:
    data: DataConfig = field(default_factory=DataConfig)
    federation: FederationConfig = field(default_factory=FederationConfig)
    fatr: FATRConfig = field(default_factory=FATRConfig)
    attack: AttackConfig = field(default_factory=AttackConfig)
    baselines: BaselineConfig = field(default_factory=BaselineConfig)
    methods: list[str] = field(default_factory=lambda: ["fedavg", "median", "trimmed_mean", "geometry_trust", "fatr"])
    attacks: list[str] = field(default_factory=lambda: ["sign_flip"])
    seeds: list[int] = field(default_factory=lambda: [42])
    target_fpr: float = 0.05
    threads: int = 1
    save_predictions: bool = True
    save_model_history: bool = True
    description: str = "New reference experiment; not a reproduction of the manuscript table."

    def validate(self) -> None:
        d, f, a, t = self.data, self.federation, self.attack, self.fatr
        if d.dataset not in ("synthetic", "rt_iot2022", "unsw_nb15"):
            raise ValueError("Unknown dataset")
        for name, value in asdict(self).items():
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError(f"Nonfinite {name}")
        for section in (d, f, a, t, self.baselines):
            for name, value in asdict(section).items():
                if isinstance(value, float) and not math.isfinite(value):
                    raise ValueError(f"Nonfinite {name}")
        if not 0 < d.test_fraction < 1 or not 0 <= d.validation_fraction < 1:
            raise ValueError("Invalid split fractions")
        if d.reference_size < 1 or d.calibration_size < 1:
            raise ValueError("Reference and calibration sizes must be positive")
        if d.scaled_clip is not None and d.scaled_clip <= 0:
            raise ValueError("scaled_clip must be positive")
        if d.shared_reference_calibration and d.calibration_size != d.reference_size:
            raise ValueError("Shared calibration must use exactly reference_size rows")
        for name in ("clients", "rounds", "minimum_client_size", "partition_retries", "local_epochs", "batch_size"):
            value = getattr(f, name)
            if not isinstance(value, int) or isinstance(value, bool) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        if f.dirichlet_alpha <= 0 or f.learning_rate <= 0 or f.server_learning_rate <= 0 or f.l2 < 0:
            raise ValueError("Invalid training or partition coefficient")
        if min(f.feature_scale_std, f.feature_bias_std, f.feature_noise_std) < 0:
            raise ValueError("Feature-shift standard deviations cannot be negative")
        if not 0 <= a.byzantine_fraction < 0.5:
            raise ValueError("This benchmark requires 0 <= Byzantine fraction < 0.5")
        if a.start_round < 1 or (a.end_round is not None and a.end_round < a.start_round):
            raise ValueError("Invalid attack activation window")
        if min(a.sign_flip_scale, a.scaling_multiplier) <= 0 or a.gaussian_relative_std < 0:
            raise ValueError("Invalid attack magnitude")
        if not 0 <= a.label_flip_fraction <= 1:
            raise ValueError("Invalid label_flip_fraction")
        if not 0 <= self.baselines.trim_fraction < 0.5:
            raise ValueError("trim_fraction must be in [0, 0.5)")
        if self.baselines.krum_byzantine_bound is not None and self.baselines.krum_byzantine_bound < 0:
            raise ValueError("Negative Krum bound")
        if not 0 <= self.target_fpr < 1 or self.threads < 1:
            raise ValueError("Invalid FPR target or thread count")
        if not self.seeds or len(set(self.seeds)) != len(self.seeds):
            raise ValueError("Seeds must be nonempty and unique")
        if any(not isinstance(s, int) or isinstance(s, bool) or s < 0 for s in self.seeds):
            raise ValueError("Seeds must be nonnegative integers")
        if not self.methods or len(set(self.methods)) != len(self.methods) or set(self.methods) - set(METHODS):
            raise ValueError(f"Methods must be unique members of {METHODS}")
        if not self.attacks or len(set(self.attacks)) != len(self.attacks) or set(self.attacks) - set(ATTACKS):
            raise ValueError(f"Attacks must be unique members of {ATTACKS}")
        for name in ("trust_ema", "history_ema"):
            if not 0 <= getattr(t, name) < 1:
                raise ValueError(f"{name} must be in [0, 1)")
        if not 0 <= t.history_gate <= 1 or not 0 <= t.initial_trust <= 1:
            raise ValueError("Invalid initial trust or history gate")
        for name in ("alpha", "beta", "gamma", "drift_lambda", "norm_mu", "clipping_k"):
            if getattr(t, name) < 0:
                raise ValueError(f"{name} cannot be negative")
        for name in ("epsilon", "drift_scale_floor", "drift_mad_factor", "max_abs_drift_z", "max_normalized_distance", "max_norm_penalty"):
            if getattr(t, name) <= 0:
                raise ValueError(f"{name} must be positive")


def deep_merge(base: dict, update: dict) -> dict:
    result = dict(base)
    for k, v in update.items():
        result[k] = deep_merge(result[k], v) if isinstance(v, dict) and isinstance(result.get(k), dict) else v
    return result


def load_config(path: Path, seen: set[Path] | None = None) -> ExperimentConfig:
    """Paths in the resolved data config are relative to the leaf YAML directory."""
    path = path.resolve()
    def read(p: Path, stack: set[Path]) -> dict:
        if p in stack:
            raise ValueError("Cyclic configuration inheritance")
        raw = yaml.safe_load(p.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("Configuration must be a mapping")
        parent = raw.pop("extends", None)
        return deep_merge(read((p.parent / parent).resolve(), stack | {p}), raw) if parent else raw
    raw = read(path, set())
    sections = {"data": DataConfig, "federation": FederationConfig, "fatr": FATRConfig,
                "attack": AttackConfig, "baselines": BaselineConfig}
    try:
        for key, cls in sections.items():
            if key in raw:
                raw[key] = cls(**raw[key])
        cfg = ExperimentConfig(**raw)
    except TypeError as exc:
        raise ValueError(f"Invalid or unknown configuration key: {exc}") from exc
    cfg.validate()
    return cfg
