"""Robust aggregators and the explicitly specified FATR reference realization.

The paper did not disclose all coefficients or numerical conventions. Every choice
below is a new, documented reference choice, NOT recovered original training code.
"""
from __future__ import annotations
from dataclasses import replace
import numpy as np
from scipy.special import expit
from .config import BaselineConfig, FATRConfig, METHODS
from .model import probability


def cosine_rows(left: np.ndarray, right: np.ndarray, epsilon: float) -> np.ndarray:
    right = np.broadcast_to(right, left.shape)
    left_norm = np.linalg.norm(left, axis=1)
    right_norm = np.linalg.norm(right, axis=1)
    good = (left_norm > epsilon) & (right_norm > epsilon)
    result = np.zeros(len(left), dtype=np.float64)
    result[good] = np.sum((left[good] / left_norm[good, None]) * (right[good] / right_norm[good, None]), axis=1)
    return np.clip(result, -1.0, 1.0)


def clip_updates(updates: np.ndarray, k: float, epsilon: float) -> tuple[np.ndarray, dict]:
    norms = np.linalg.norm(updates, axis=1)
    median_norm = float(np.median(norms))
    mad_norm = float(np.median(np.abs(norms - median_norm)))
    cap = median_norm + k * mad_norm  # Raw MAD, no consistency factor here.
    factors = np.minimum(1.0, cap / np.maximum(norms, epsilon))
    # A zero median and zero MAD intentionally clips every vector to zero.
    clipped = updates * factors[:, None]
    return clipped, {"median_norm": median_norm, "mad_norm": mad_norm, "clip_cap": cap,
                     "raw_norms": norms, "clip_factors": factors}


def krum(updates: np.ndarray, byzantine_bound: int) -> np.ndarray:
    """Single-Krum: sum squared distances to n-f-2 OTHER nearest updates."""
    n = len(updates)
    if byzantine_bound < 0 or n <= 2 * byzantine_bound + 2:
        raise ValueError("Krum requires n > 2*f + 2 after invalid updates are excluded")
    dist2 = np.sum((updates[:, None, :] - updates[None, :, :]) ** 2, axis=2)
    np.fill_diagonal(dist2, np.inf)
    neighbors = n - byzantine_bound - 2
    scores = np.sort(dist2, axis=1)[:, :neighbors].sum(axis=1)
    return updates[int(np.argmin(scores))].copy()  # Ties use the lowest client position.


class Aggregator:
    """Full-participation simulation with persistent, verified client indices."""
    def __init__(self, method: str, clients: int, dimensions: int, cfg: FATRConfig,
                 baselines: BaselineConfig, byzantine_bound: int):
        if method not in METHODS:
            raise ValueError(f"Unsupported method: {method}")
        self.method = method
        self.cfg = replace(cfg)
        if method in ("geometry_trust", "fatr_no_history"):
            self.cfg.beta = 0.0
        if method in ("geometry_trust", "fatr_no_drift"):
            self.cfg.drift_lambda = 0.0
        if method == "fatr_no_clipping":
            self.cfg.clipping = False
        if method == "fatr_no_smoothing":
            self.cfg.trust_ema = 0.0
        self.baselines = baselines
        self.byzantine_bound = byzantine_bound
        self.trust = np.full(clients, self.cfg.initial_trust, dtype=np.float64)
        self.history = np.zeros((clients, dimensions), dtype=np.float64)
        self.trust_method = method not in ("fedavg", "median", "trimmed_mean", "krum")

    def aggregate(self, updates: np.ndarray, sizes: np.ndarray, theta: np.ndarray,
                  reference_X: np.ndarray) -> tuple[np.ndarray, dict]:
        updates = np.asarray(updates, dtype=np.float64)
        sizes = np.asarray(sizes, dtype=np.float64)
        if updates.shape != self.history.shape or sizes.shape != (len(updates),):
            raise ValueError("Aggregation dimensions do not match enrolled clients")
        if theta.shape != (updates.shape[1],) or not np.isfinite(theta).all():
            raise ValueError("Invalid server model")
        if not np.isfinite(sizes).all() or np.any(sizes <= 0):
            raise ValueError("Verified sample counts must be finite and positive")
        # This numerical guard is common to ALL methods, not a FATR-only defense.
        valid = np.isfinite(updates).all(axis=1) & (np.max(np.abs(updates), axis=1) <= 1e100)
        indices = np.flatnonzero(valid)
        self.trust[~valid] = 0.0
        info = {"valid": valid, "fallback": "none", "trust": self.trust.copy() if self.trust_method else None}
        if len(indices) == 0:
            info["fallback"] = "all_invalid_no_update"
            return np.zeros_like(theta), info
        U, count = updates[valid].copy(), sizes[valid]
        if self.method == "fedavg":
            return np.average(U, axis=0, weights=count), info
        if self.method == "median":
            return np.median(U, axis=0), info
        if self.method == "trimmed_mean":
            trim = int(np.floor(len(U) * self.baselines.trim_fraction))
            ordered = np.sort(U, axis=0)
            retained = ordered[trim:len(U) - trim] if trim else ordered
            return retained.mean(axis=0), info
        if self.method == "krum":
            try:
                return krum(U, self.byzantine_bound), info
            except ValueError:
                # Insufficient valid participants: conservative no-op, not silent FedAvg.
                info["fallback"] = "krum_insufficient_valid_no_update"
                return np.zeros_like(theta), info
        c = self.cfg
        clipped, clip_info = clip_updates(U, c.clipping_k, c.epsilon)
        V = clipped if c.clipping else U
        center = np.median(V, axis=0)
        distances = np.linalg.norm(V - center, axis=1)
        normalized_distance = np.minimum(distances / max(float(np.median(distances)), c.epsilon), c.max_normalized_distance)
        alignment = cosine_rows(V, center, c.epsilon)
        history_alignment = cosine_rows(V, self.history[valid], c.epsilon) if c.beta else np.zeros(len(V))
        norm_penalty = np.clip(clip_info["raw_norms"] / max(clip_info["median_norm"], c.epsilon) - 1.0, 0, c.max_norm_penalty)
        drift = np.zeros(len(V))
        z = np.zeros(len(V))
        if c.drift_lambda:
            if reference_X.ndim != 2 or not len(reference_X) or reference_X.shape[1] + 1 != len(theta):
                raise ValueError("FATR drift requires a nonempty, correctly shaped benign reference")
            if not np.isfinite(reference_X).all():
                raise ValueError("Nonfinite reference features")
            base = probability(theta, reference_X)
            candidates = theta[None, :] + V
            predictions = expit(reference_X @ candidates[:, :-1].T + candidates[:, -1][None, :])
            drift = (predictions - base[:, None]).mean(axis=0)
            center_drift = float(np.median(drift))
            scale = max(c.drift_mad_factor * float(np.median(np.abs(drift - center_drift))), c.drift_scale_floor)
            z = np.clip((drift - center_drift) / scale, -c.max_abs_drift_z, c.max_abs_drift_z)
        score = c.alpha * alignment + c.beta * history_alignment - c.gamma * normalized_distance - c.drift_lambda * np.abs(z) - c.norm_mu * norm_penalty
        self.trust[valid] = c.trust_ema * self.trust[valid] + (1.0 - c.trust_ema) * expit(score)
        weights = self.trust[valid] * count
        if np.sum(weights) <= c.epsilon:
            delta = center.copy()
            info["fallback"] = "zero_weight_coordinate_median"
        else:
            delta = np.average(V, axis=0, weights=weights)
        # Current trust gates history updates; zero initial history has cosine zero.
        if c.beta:
            accepted = self.trust[valid] >= c.history_gate
            accepted_ids = indices[accepted]
            self.history[accepted_ids] = c.history_ema * self.history[accepted_ids] + (1.0 - c.history_ema) * V[accepted]
        def full(values: np.ndarray) -> np.ndarray:
            result = np.full(len(updates), np.nan)
            result[valid] = values
            return result
        info.update({"trust": self.trust.copy(), "score": full(score), "drift": full(drift),
                     "drift_z": full(z), "alignment": full(alignment),
                     "history_alignment": full(history_alignment), "normalized_distance": full(normalized_distance),
                     "norm_penalty": full(norm_penalty), "raw_norm": full(clip_info["raw_norms"]),
                     "clip_factor": full(clip_info["clip_factors"] if c.clipping else np.ones(len(V))),
                     "normalized_weight": full(weights / weights.sum() if weights.sum() > c.epsilon else np.zeros_like(weights)),
                     "clip_cap": clip_info["clip_cap"], "history_updated": (self.trust >= c.history_gate) & valid if c.beta else np.zeros(len(valid), dtype=bool)})
        if not np.isfinite(delta).all():
            raise FloatingPointError("Nonfinite aggregate; inspect client updates")
        return delta, info
