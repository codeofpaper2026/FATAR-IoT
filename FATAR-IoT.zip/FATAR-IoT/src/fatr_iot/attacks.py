"""Local, offline poisoning simulations only. No network attack functionality."""
from __future__ import annotations
import numpy as np
from .config import ATTACKS, AttackConfig


def attack_active(round_number: int, cfg: AttackConfig) -> bool:
    return round_number >= cfg.start_round and (cfg.end_round is None or round_number <= cfg.end_round)


def poison_labels(y: np.ndarray, fraction: float, rng: np.random.Generator) -> np.ndarray:
    if not 0 <= fraction <= 1:
        raise ValueError("Label-flip fraction must be in [0,1]")
    result = y.copy()
    indices = rng.choice(len(y), size=int(np.floor(len(y) * fraction)), replace=False)
    result[indices] = 1 - result[indices]
    return result


def poison_update(delta: np.ndarray, name: str, cfg: AttackConfig, rng: np.random.Generator) -> np.ndarray:
    if name not in ATTACKS:
        raise ValueError(f"Unknown attack: {name}")
    if name == "sign_flip":
        return -cfg.sign_flip_scale * delta
    if name == "scaling":
        return cfg.scaling_multiplier * delta
    if name == "gaussian":
        per_coordinate_std = cfg.gaussian_relative_std * np.linalg.norm(delta) / np.sqrt(len(delta))
        return delta + rng.normal(0.0, per_coordinate_std, size=delta.shape)
    # For label_flip, training has already used poisoned labels.
    return delta.copy()
