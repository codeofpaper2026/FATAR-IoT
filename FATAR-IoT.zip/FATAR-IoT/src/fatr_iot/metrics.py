"""Threshold calibration and binary metrics, with attack encoded as one."""
from __future__ import annotations
import math
import numpy as np
from sklearn.metrics import average_precision_score, roc_auc_score


def calibrate_threshold(benign_scores: np.ndarray, target_fpr: float) -> float:
    """Order statistic; strict score > threshold ensures empirical FPR <= target.

    This is an in-buffer property only, not a guarantee for future observations.
    At target zero use the maximum. Ties are classified as benign.
    """
    scores = np.asarray(benign_scores, dtype=np.float64)
    if scores.ndim != 1 or len(scores) == 0 or not np.isfinite(scores).all():
        raise ValueError("Calibration requires nonempty, finite, one-dimensional scores")
    if not 0 <= target_fpr < 1:
        raise ValueError("FPR target must be in [0,1)")
    allowed = math.floor(len(scores) * target_fpr)
    index = len(scores) - allowed - 1
    return float(np.partition(scores, index)[index])


def binary_metrics(y: np.ndarray, scores: np.ndarray, threshold: float) -> dict:
    y = np.asarray(y)
    scores = np.asarray(scores)
    if y.ndim != 1 or scores.shape != y.shape or len(y) == 0:
        raise ValueError("Invalid metric dimensions")
    if not set(np.unique(y)).issubset({0, 1}) or not np.isfinite(scores).all() or not np.isfinite(threshold):
        raise ValueError("Metrics require binary labels and finite scores/threshold")
    pred = scores > threshold
    tp = int(np.sum(pred & (y == 1)))
    tn = int(np.sum(~pred & (y == 0)))
    fp = int(np.sum(pred & (y == 0)))
    fn = int(np.sum(~pred & (y == 1)))
    ratio = lambda a, b: float(a / b) if b else None
    denominator = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    two_classes = len(np.unique(y)) == 2
    return {
        "tn": tn, "fp": fp, "fn": fn, "tp": tp,
        "accuracy": (tp + tn) / len(y), "precision": ratio(tp, tp + fp),
        "recall": ratio(tp, tp + fn), "fpr": ratio(fp, fp + tn),
        "f1": ratio(2 * tp, 2 * tp + fp + fn),
        "mcc": ratio(tp * tn - fp * fn, denominator),
        "auc": float(roc_auc_score(y, scores)) if two_classes else None,
        "average_precision": float(average_precision_score(y, scores)) if two_classes else None,
    }
