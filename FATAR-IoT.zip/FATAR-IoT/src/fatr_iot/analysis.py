"""Independent-seed summaries and paired bootstrap intervals for NEW experiments."""
from __future__ import annotations
from pathlib import Path
import json
import numpy as np
import pandas as pd
from .utils import rng_for, write_json

METRICS = ("accuracy", "precision", "recall", "f1", "auc", "average_precision", "fpr", "mcc", "aggregation_seconds")


def summarize(output: Path, bootstrap_samples: int = 5000) -> dict:
    if bootstrap_samples < 100:
        raise ValueError("Use at least 100 bootstrap resamples")
    files = sorted(output.glob("seed_*/*/*/result.json"))
    if not files:
        raise FileNotFoundError(f"No completed results under {output}")
    rows = []
    for path in files:
        result = json.loads(path.read_text(encoding="utf-8"))
        rows.append({"dataset": result["dataset"], **result["final"]})
    table = pd.DataFrame(rows)
    keys = ["dataset", "attack", "method", "seed"]
    if table.duplicated(keys).any():
        raise ValueError("Duplicate dataset/attack/method/seed; cannot treat them as independent runs")
    table.to_csv(output / "final_per_run.csv", index=False)
    summary = []
    for (dataset, attack, method), group in table.groupby(["dataset", "attack", "method"], sort=True):
        row = {"dataset": dataset, "attack": attack, "method": method, "n_runs": len(group)}
        for metric in METRICS:
            values = pd.to_numeric(group[metric], errors="coerce").dropna().to_numpy()
            row[f"{metric}_n"] = len(values)
            row[f"{metric}_mean"] = float(values.mean()) if len(values) else None
            row[f"{metric}_sample_sd"] = float(values.std(ddof=1)) if len(values) > 1 else None
        summary.append(row)
    pd.DataFrame(summary).to_csv(output / "summary.csv", index=False)
    comparisons = []
    for (dataset, attack), group in table.groupby(["dataset", "attack"], sort=True):
        baseline = group[group.method == "fatr"].set_index("seed")
        if baseline.empty:
            continue
        for method, other in group[group.method != "fatr"].groupby("method", sort=True):
            other = other.set_index("seed")
            seeds = sorted(set(baseline.index) & set(other.index))
            for metric in ("f1", "fpr", "recall", "mcc"):
                differences = (baseline.loc[seeds, metric] - other.loc[seeds, metric]).dropna().to_numpy(dtype=float)
                n = len(differences)
                ci = [None, None]
                if n > 1:
                    # Separate deterministic analysis RNG; does not touch training randomness.
                    rng = rng_for(2026, 100, len(comparisons))
                    means = differences[rng.integers(0, n, size=(bootstrap_samples, n))].mean(axis=1)
                    ci = np.quantile(means, [0.025, 0.975]).tolist()
                comparisons.append({"dataset": dataset, "attack": attack, "comparison": f"fatr_minus_{method}",
                    "metric": metric, "n_paired_seeds": n, "mean_difference": float(differences.mean()) if n else None,
                    "paired_percentile_bootstrap_95_low": ci[0], "paired_percentile_bootstrap_95_high": ci[1],
                    "bootstrap_samples": bootstrap_samples if n > 1 else 0,
                    "warning": "Exploratory interval conditional on dataset; very small seed counts are unreliable; no multiplicity correction"})
    if comparisons:
        pd.DataFrame(comparisons).to_csv(output / "paired_differences.csv", index=False)
    info = {"runs": len(table), "groups": len(summary), "summaries": summary,
            "paired_comparisons": comparisons,
            "uncertainty_unit": "final-round result of independent seeded reruns on one fixed dataset",
            "not_uncertainty_unit": "successive communication rounds",
            "no_original_paper_reproduction_claim": True}
    write_json(output / "summary.json", info)
    return info


def plot_learning_curves(output: Path) -> list[Path]:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    paths = sorted(output.glob("seed_*/*/*/round_metrics.csv"))
    if not paths:
        raise FileNotFoundError("No round metrics to plot")
    frame = pd.concat([pd.read_csv(p) for p in paths], ignore_index=True)
    plot_dir = output / "plots"
    plot_dir.mkdir(exist_ok=True)
    generated = []
    for attack, group in frame.groupby("attack", sort=True):
        for metric in ("f1", "fpr", "recall", "auc"):
            fig, ax = plt.subplots(figsize=(7.5, 4.5))
            for method, sub in group.groupby("method", sort=True):
                stats = sub.groupby("round")[metric].agg(["mean", "std", "count"])
                # Error bars are BETWEEN seeds at each round, not temporal SD.
                ax.errorbar(stats.index, stats["mean"], yerr=stats["std"].fillna(0),
                            label=method, linewidth=1.2, capsize=2, errorevery=3)
            if metric == "fpr":
                target = float(group["target_fpr"].iloc[0])
                ax.axhline(target, linestyle="--", linewidth=1, label="calibration target (not test bound)")
            ax.set(xlabel="Communication round", ylabel=metric.upper(),
                   title=f"Reference implementation: {attack} (mean +/- seed SD)")
            ax.legend(fontsize=7)
            ax.grid(alpha=0.25)
            fig.tight_layout()
            path = plot_dir / f"{attack}_{metric}.png"
            fig.savefig(path, dpi=180)
            plt.close(fig)
            generated.append(path)
    return generated
