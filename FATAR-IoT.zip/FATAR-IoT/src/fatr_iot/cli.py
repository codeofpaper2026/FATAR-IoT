"""Command-line entry points. Paths are explicit; outputs are never overwritten."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from .analysis import summarize, plot_learning_curves
from .config import load_config
from .data import Preprocessor, load_raw, prepare_data, synthetic_dataset
from .download import fetch_rt_iot2022
from .experiment import run_campaign
from .model import probability


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="fatr-iot", description="FATR-IoT: new reference implementation, not original manuscript reproduction")
    commands = parser.add_subparsers(dest="command", required=True)
    p = commands.add_parser("generate", help="Generate a NEW synthetic dataset; never original experimental data")
    p.add_argument("--output", type=Path, default=Path("data/synthetic"))
    p.add_argument("--samples", type=int, default=30000)
    p.add_argument("--seed", type=int, default=42)
    p = commands.add_parser("fetch", help="Explicitly download the official UCI RT-IoT2022 data")
    p.add_argument("dataset", choices=["rt_iot2022"])
    p.add_argument("--output", type=Path, default=Path("data/raw/rt_iot2022"))
    p.add_argument("--expected-sha256")
    p.add_argument("--archive", type=Path, help="Use a local official ZIP instead of making a network request")
    p = commands.add_parser("prepare", help="Save disjoint arrays, split identifiers and fitted preprocessing")
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--seed", type=int, default=42)
    p = commands.add_parser("run", help="Run all methods, attacks and seeds specified in the YAML")
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--seeds", type=int, nargs="+")
    p.add_argument("--methods", nargs="+")
    p.add_argument("--attacks", nargs="+")
    p.add_argument("--rounds", type=int)
    p.add_argument("--plots", action="store_true")
    p = commands.add_parser("summarize", help="Summarize independent final-round runs, not temporal SD")
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--bootstrap-samples", type=int, default=5000)
    p = commands.add_parser("plot", help="Plot measured runs, with across-seed SD")
    p.add_argument("--input", type=Path, required=True)
    p = commands.add_parser("predict", help="Score local CSV features using a saved model and safe JSON preprocessing")
    p.add_argument("--model-dir", type=Path, required=True)
    p.add_argument("--csv", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "generate":
            print(synthetic_dataset(args.output, args.samples, args.seed))
        elif args.command == "fetch":
            print(fetch_rt_iot2022(args.output, args.expected_sha256, args.archive))
        elif args.command == "prepare":
            cfg = load_config(args.config)
            if args.output.exists() and any(args.output.iterdir()):
                raise FileExistsError("Preparation output must be absent or empty")
            raw = load_raw(cfg.data, args.config.resolve().parent)
            data = prepare_data(raw, cfg.data, args.seed)
            data.save(args.output)
            print(json.dumps(data.manifest["splits"], indent=2))
        elif args.command == "run":
            cfg = load_config(args.config)
            for name in ("seeds", "methods", "attacks"):
                value = getattr(args, name)
                if value is not None:
                    setattr(cfg, name, value)
            if args.rounds is not None:
                cfg.federation.rounds = args.rounds
            cfg.validate()
            run_campaign(cfg, args.config.resolve().parent, args.output)
            summarize(args.output)
            if args.plots:
                plot_learning_curves(args.output)
        elif args.command == "summarize":
            summarize(args.input, args.bootstrap_samples)
        elif args.command == "plot":
            plot_learning_curves(args.input)
        elif args.command == "predict":
            if args.output.exists():
                raise FileExistsError("Prediction output already exists")
            prep = Preprocessor()
            prep.state = json.loads((args.model_dir / "preprocessor.json").read_text(encoding="utf-8"))
            frame = pd.read_csv(args.csv, low_memory=False, float_precision="round_trip")
            with np.load(args.model_dir / "model.npz", allow_pickle=False) as model:
                scores = probability(model["theta"], prep.transform(frame))
                threshold = float(model["threshold"])
            rows = frame["row_id"].astype(str) if "row_id" in frame else np.arange(len(frame))
            args.output.parent.mkdir(parents=True, exist_ok=True)
            pd.DataFrame({"row_id": rows, "attack_probability": scores,
                          "prediction": (scores > threshold).astype(int), "threshold": threshold}).to_csv(args.output, index=False)
    except (ValueError, OSError, RuntimeError, KeyError, FloatingPointError) as exc:
        parser.exit(2, f"error: {exc}\n")
    return 0
