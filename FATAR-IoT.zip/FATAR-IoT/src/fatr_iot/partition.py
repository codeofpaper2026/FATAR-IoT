"""Label-wise Dirichlet allocation, without silently repairing the sampled skew."""
from __future__ import annotations
import numpy as np


def dirichlet_partition(y: np.ndarray, clients: int, alpha: float, minimum: int,
                        retries: int, rng: np.random.Generator) -> tuple[list[np.ndarray], dict]:
    if clients < 1 or alpha <= 0 or minimum < 1 or retries < 1:
        raise ValueError("Invalid partition settings")
    if len(y) < clients * minimum:
        raise ValueError("Too few training rows for the required minimum client size")
    labels = np.unique(y)
    for attempt in range(1, retries + 1):
        buckets: list[list[int]] = [[] for _ in range(clients)]
        probabilities = {}
        for label in labels:
            indices = rng.permutation(np.flatnonzero(y == label))
            proportions = rng.dirichlet(np.full(clients, alpha))
            counts = rng.multinomial(len(indices), proportions)
            probabilities[str(int(label))] = proportions.tolist()
            chunks = np.split(indices, np.cumsum(counts)[:-1])
            for i, chunk in enumerate(chunks):
                buckets[i].extend(chunk.tolist())
        if min(map(len, buckets)) >= minimum:
            parts = [rng.permutation(np.asarray(bucket, dtype=np.int64)) for bucket in buckets]
            return parts, {"variant": "label-wise Dirichlet then multinomial counts; reject whole draw if min size fails",
                           "alpha": alpha, "attempts": attempt, "minimum_size": minimum,
                           "probabilities": probabilities,
                           "clients": [{"client_id": i, "n": len(p), "benign": int(np.sum(y[p] == 0)),
                                        "attack": int(np.sum(y[p] == 1))} for i, p in enumerate(parts)]}
    raise ValueError("Dirichlet partition failed minimum-size constraint within retry budget")
