"""Offline synthetic data, public CSV adapters and auditable disjoint splits.

No bundled or newly generated data are the unavailable original paper dataset.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import importlib.metadata
import re
import warnings
import numpy as np
import pandas as pd
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from .config import DataConfig
from .utils import rng_for, seed_for, sha256_file, write_json

NORMAL_RT = {"mqtt", "mqttpublish", "thingspeak", "wiprobulb", "wiprobulbdataset", "amazonalexa"}
ATTACK_RT = {"dossynhping", "arppoisioning", "arppoisoning", "nmapudpscan", "nmapxmastreescan", "nmaposdetection", "nmaptcpscan",
             "ddosslowloris", "metasploitbruteforcessh", "nmapfinscan"}
SPLITS = ("train", "validation", "reference", "calibration", "test")


def synthetic_dataset(output: Path, samples: int = 30000, seed: int = 42) -> Path:
    """Create a NEW generic binary toy benchmark with fully declared arguments."""
    if samples < 100 or seed < 0:
        raise ValueError("Use at least 100 samples and a nonnegative seed")
    output.mkdir(parents=True, exist_ok=True)
    path = output / "synthetic_v1.csv.gz"
    if path.exists():
        raise FileExistsError(f"Refusing to replace {path}; choose an empty destination")
    kwargs = dict(n_samples=samples, n_features=20, n_informative=12, n_redundant=4,
                  n_repeated=0, n_classes=2, n_clusters_per_class=2, weights=[0.85, 0.15],
                  flip_y=0.02, class_sep=1.0, hypercube=True, shift=0.0, scale=1.0,
                  shuffle=True, random_state=seed)
    X, y = make_classification(**kwargs)
    table = pd.DataFrame(X, columns=[f"x{i:02d}" for i in range(20)])
    table.insert(0, "row_id", [f"synthetic-{i:07d}" for i in range(samples)])
    table["label"] = y.astype(np.int8)
    table.to_csv(path, index=False, float_format="%.17g", compression={"method": "gzip", "mtime": 0})
    write_json(output / "manifest.json", {
        "dataset": "FATR synthetic_v1", "provenance": "new_reference_dataset_not_original_manuscript_data",
        "generator": "sklearn.datasets.make_classification", "arguments": kwargs,
        "generator_library_versions": {"scikit-learn": importlib.metadata.version("scikit-learn"), "numpy": np.__version__},
        "rows": samples, "features": 20,
        "class_counts": {str(k): int(v) for k, v in table.label.value_counts().sort_index().items()},
        "file": path.name, "sha256": sha256_file(path),
        "license": "MIT (newly generated artifact; contains no measured network traffic)",
    })
    return path


@dataclass
class RawData:
    X: pd.DataFrame
    y: np.ndarray
    ids: np.ndarray
    groups: np.ndarray
    predefined_test: np.ndarray | None
    provenance: dict


def _read_csv(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(f"Dataset file not found: {path}. See docs/DATASETS.md.")
    table = pd.read_csv(path, low_memory=False, float_precision="round_trip")
    if len(table) == 0 or table.columns.duplicated().any():
        raise ValueError("Dataset is empty or has duplicate column names")
    return table


def load_raw(cfg: DataConfig, base: Path) -> RawData:
    source = (base / cfg.source).resolve()
    frame = _read_csv(source)
    origins = np.full(len(frame), False)
    ids = np.asarray([f"train-{i:08d}" for i in range(len(frame))])
    files = [{"name": source.name, "sha256": sha256_file(source), "rows": len(frame)}]
    if cfg.dataset == "synthetic":
        expected = [f"x{i:02d}" for i in range(20)]
        if not set(expected + ["label", "row_id"]).issubset(frame.columns):
            raise ValueError("Synthetic CSV must contain row_id, x00..x19 and label")
        X = frame[expected].copy()
        y = frame["label"].to_numpy()
        ids = frame["row_id"].astype(str).to_numpy()
        groups = np.where(y == 0, "synthetic_benign", "synthetic_attack")
    elif cfg.dataset == "rt_iot2022":
        if "Attack_type" not in frame:
            raise ValueError("RT-IoT2022 requires the original Attack_type column")
        groups = frame["Attack_type"].astype(str).to_numpy()
        normalized = np.asarray([re.sub(r"[^a-z0-9]", "", x.lower()) for x in groups])
        unknown = set(normalized) - NORMAL_RT - ATTACK_RT
        if unknown:
            raise ValueError(f"Unrecognized RT-IoT2022 labels: {sorted(unknown)}. Verify mapping against the source.")
        y = (~np.isin(normalized, list(NORMAL_RT))).astype(np.int8)
        X = frame.drop(columns=[c for c in frame if c == "Attack_type" or c.lower().startswith("unnamed:")])
    elif cfg.dataset == "unsw_nb15":
        if not cfg.testing_source:
            raise ValueError("UNSW-NB15 requires testing_source; the official test set is preserved")
        test_path = (base / cfg.testing_source).resolve()
        test = _read_csv(test_path)
        if set(test.columns) != set(frame.columns):
            raise ValueError("UNSW-NB15 train/test columns differ")
        if not {"label", "attack_cat"}.issubset(frame):
            raise ValueError("UNSW-NB15 CSVs require label and attack_cat")
        files.append({"name": test_path.name, "sha256": sha256_file(test_path), "rows": len(test)})
        origins = np.r_[np.zeros(len(frame), dtype=bool), np.ones(len(test), dtype=bool)]
        ids = np.asarray([f"train-{i:08d}" for i in range(len(frame))] + [f"test-{i:08d}" for i in range(len(test))])
        frame = pd.concat([frame, test], ignore_index=True)
        y = pd.to_numeric(frame["label"], errors="raise").to_numpy()
        groups = frame["attack_cat"].fillna("Normal").astype(str).str.strip().to_numpy()
        X = frame.drop(columns=[c for c in frame if c in ("id", "label", "attack_cat") or c.lower().startswith("unnamed:")])
    else:
        raise ValueError(f"Unsupported dataset: {cfg.dataset}")
    if not set(np.unique(y)).issubset({0, 1}) or len(np.unique(y)) != 2:
        raise ValueError("Expected both binary labels: benign=0 and attack=1")
    if len(set(ids)) != len(ids):
        raise ValueError("Row identifiers must be unique")
    provenance = {"dataset": cfg.dataset, "files": files, "input_rows": len(y),
                  "input_features": list(X.columns), "target_mapping": "benign=0; attack=1"}
    return RawData(X.reset_index(drop=True), y.astype(np.int8), ids, groups,
                   origins if cfg.dataset == "unsw_nb15" else None, provenance)


class Preprocessor:
    """Training-only median imputation, optional signed log, z-scaling and one-hot.

    All fitted state is plain JSON. No pickle/joblib is needed to load a model.
    Categorical values absent from training map to an all-zero indicator vector.
    """
    def __init__(self, signed_log1p: bool = False, scaled_clip: float | None = None):
        self.signed_log1p = signed_log1p
        self.scaled_clip = scaled_clip
        self.state: dict = {}

    def fit(self, frame: pd.DataFrame) -> "Preprocessor":
        if len(frame) == 0:
            raise ValueError("Cannot fit preprocessing on an empty training set")
        numeric = [c for c in frame if pd.api.types.is_numeric_dtype(frame[c])]
        categorical = [c for c in frame if c not in numeric]
        values = frame[numeric].to_numpy(dtype=np.float64, copy=True)
        values[~np.isfinite(values)] = np.nan
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=RuntimeWarning)
            medians = np.nanmedian(values, axis=0)
        medians = np.where(np.isfinite(medians), medians, 0.0)
        values = np.where(np.isnan(values), medians, values)
        if self.signed_log1p:
            values = np.sign(values) * np.log1p(np.abs(values))
        means, scales = values.mean(axis=0), values.std(axis=0, ddof=0)
        scales = np.where(scales > 1e-12, scales, 1.0)
        cats = {c: sorted(frame[c].fillna("__MISSING__").astype(str).unique().tolist()) for c in categorical}
        names = numeric + [f"{c}={v}" for c in categorical for v in cats[c]]
        self.state = {"numeric": numeric, "categorical": categorical, "medians": medians.tolist(),
                      "means": means.tolist(), "scales": scales.tolist(), "categories": cats,
                      "feature_names": names, "signed_log1p": self.signed_log1p,
                      "scaled_clip": self.scaled_clip, "fit_rows": len(frame)}
        return self

    def transform(self, frame: pd.DataFrame) -> np.ndarray:
        if not self.state:
            raise ValueError("Preprocessor is not fitted")
        s = self.state
        values = frame[s["numeric"]].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float64)
        values = np.where(np.isfinite(values), values, np.asarray(s["medians"]))
        if s["signed_log1p"]:
            values = np.sign(values) * np.log1p(np.abs(values))
        values = (values - np.asarray(s["means"])) / np.asarray(s["scales"])
        if s["scaled_clip"] is not None:
            values = np.clip(values, -s["scaled_clip"], s["scaled_clip"])
        blocks = [values]
        for col in s["categorical"]:
            col_values = frame[col].fillna("__MISSING__").astype(str).to_numpy()
            blocks.append((col_values[:, None] == np.asarray(s["categories"][col])[None, :]).astype(np.float64))
        result = np.ascontiguousarray(np.hstack(blocks), dtype=np.float64)
        if not np.isfinite(result).all():
            raise ValueError("Nonfinite transformed data")
        return result


@dataclass
class PreparedData:
    arrays: dict[str, np.ndarray]
    manifest: dict
    preprocessor: dict

    def save(self, output: Path) -> None:
        output.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(output / "dataset.npz", **self.arrays)
        write_json(output / "preprocessor.json", self.preprocessor)
        rows = []
        for name in SPLITS:
            for rid, y, group in zip(self.arrays[f"{name}_ids"], self.arrays[f"{name}_y"], self.arrays[f"{name}_groups"]):
                rows.append({"row_id": rid, "split": name, "label": int(y), "attack_type": group})
        pd.DataFrame(rows).to_csv(output / "split_ids.csv", index=False)
        self.manifest["prepared_sha256"] = sha256_file(output / "dataset.npz")
        write_json(output / "manifest.json", self.manifest)


def _split(indices: np.ndarray, labels: np.ndarray, test_size: float, seed: int) -> tuple[np.ndarray, np.ndarray]:
    if test_size == 0:
        return indices, np.asarray([], dtype=np.int64)
    try:
        train, test = train_test_split(indices, test_size=test_size, random_state=seed, stratify=labels[indices])
    except ValueError as exc:
        raise ValueError("Not enough examples for a stratified binary split; change sample sizes") from exc
    return np.asarray(train), np.asarray(test)


def prepare_data(raw: RawData, cfg: DataConfig, seed: int) -> PreparedData:
    """Split BEFORE fitting transformations and keep calibration independent by default."""
    # Fingerprints exclude labels and IDs. Duplicate feature rows cannot cross splits.
    fingerprints = pd.util.hash_pandas_object(raw.X, index=False).to_numpy()
    group_frame = pd.DataFrame({"fingerprint": fingerprints, "label": raw.y})
    conflicts = group_frame.groupby("fingerprint")["label"].nunique()
    conflict_keys = conflicts.index[conflicts > 1].to_numpy()
    n_conflicts = int(np.sum(np.isin(fingerprints, conflict_keys)))
    # Labels are used for an audit only, never to decide which feature rows survive.
    # This prevents official test labels from changing the retained training pool.
    valid = np.ones(len(raw.y), dtype=bool)
    if cfg.deduplicate:
        valid = ~pd.Series(fingerprints).duplicated(keep="first").to_numpy()
    selected = np.flatnonzero(valid)
    if raw.predefined_test is not None:
        # Keep original test membership; remove test overlaps/duplicates, do not move them into training.
        train_pool = selected[~raw.predefined_test[selected]]
        test_idx = selected[raw.predefined_test[selected]]
    else:
        train_pool, test_idx = _split(selected, raw.y, cfg.test_fraction, seed_for(seed, 10))
    train_pool, validation_idx = _split(train_pool, raw.y, cfg.validation_fraction, seed_for(seed, 11))
    benign = train_pool[raw.y[train_pool] == 0]
    required = cfg.reference_size + (0 if cfg.shared_reference_calibration else cfg.calibration_size)
    if len(benign) < required + 2:
        raise ValueError(f"Need at least {required + 2} benign training-pool rows; found {len(benign)}")
    chosen = rng_for(seed, 12).permutation(benign)[:required]
    reference_idx = chosen[:cfg.reference_size]
    calibration_idx = reference_idx.copy() if cfg.shared_reference_calibration else chosen[cfg.reference_size:]
    train_idx = train_pool[~np.isin(train_pool, chosen)]
    split_map = {"train": train_idx, "validation": validation_idx, "reference": reference_idx,
                 "calibration": calibration_idx, "test": test_idx}
    if len(np.unique(raw.y[train_idx])) != 2 or len(np.unique(raw.y[test_idx])) != 2:
        raise ValueError("Training/test data must each contain benign and attack examples")
    overlap = {}
    for i, left in enumerate(SPLITS):
        for right in SPLITS[i + 1:]:
            count = len(np.intersect1d(fingerprints[split_map[left]], fingerprints[split_map[right]]))
            overlap[f"{left}:{right}"] = count
            shared = cfg.shared_reference_calibration and {left, right} == {"reference", "calibration"}
            if count and not shared:
                raise ValueError(f"Feature duplicate leakage between {left} and {right}; use deduplicate=true")
    prep = Preprocessor(cfg.signed_log1p, cfg.scaled_clip).fit(raw.X.iloc[train_idx])
    arrays: dict[str, np.ndarray] = {}
    for name, idx in split_map.items():
        arrays[f"{name}_X"] = prep.transform(raw.X.iloc[idx])
        arrays[f"{name}_y"] = raw.y[idx].copy()
        arrays[f"{name}_ids"] = raw.ids[idx].astype(str)
        arrays[f"{name}_groups"] = raw.groups[idx].astype(str)
    arrays["feature_names"] = np.asarray(prep.state["feature_names"], dtype=str)
    manifest = dict(raw.provenance)
    manifest.update({
        "implementation_status": "new_reference_implementation_not_original_experiment",
        "seed": seed, "numeric_dtype": "float64", "features_after_encoding": len(prep.state["feature_names"]),
        "deduplicate": cfg.deduplicate, "conflicting_feature_rows_observed": n_conflicts,
        "label_conflict_policy": "audit only; feature duplicates keep first occurrence without using labels",
        "total_rows_removed": len(raw.y) - len(selected), "split_unit": "rows, not devices/sessions/time",
        "predefined_test_membership_preserved": raw.predefined_test is not None,
        "preprocessing_fit_population": "client training rows only, centralized offline simulation",
        "shared_reference_calibration": cfg.shared_reference_calibration,
        "cross_split_feature_hash_overlaps": overlap,
        "splits": {name: {"rows": len(idx), "benign": int(np.sum(raw.y[idx] == 0)),
                           "attack": int(np.sum(raw.y[idx] == 1)),
                           "attack_type_counts": pd.Series(raw.groups[idx]).value_counts().to_dict()}
                   for name, idx in split_map.items()},
    })
    return PreparedData(arrays, manifest, prep.state)
