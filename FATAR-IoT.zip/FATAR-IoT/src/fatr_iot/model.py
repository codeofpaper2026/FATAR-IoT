"""Explicit float64 binary logistic regression with mini-batch SGD."""
from __future__ import annotations
import numpy as np
from scipy.special import expit
from .config import FederationConfig


def probability(theta: np.ndarray, X: np.ndarray) -> np.ndarray:
    return expit(X @ theta[:-1] + theta[-1])


def gradient(theta: np.ndarray, X: np.ndarray, y: np.ndarray, l2: float = 0.0) -> np.ndarray:
    residual = probability(theta, X) - y
    return np.r_[X.T @ residual / len(y) + l2 * theta[:-1], residual.mean()]


def logistic_loss(theta: np.ndarray, X: np.ndarray, y: np.ndarray, l2: float = 0.0) -> float:
    logits = X @ theta[:-1] + theta[-1]
    return float(np.mean(np.logaddexp(0.0, logits) - y * logits) + 0.5 * l2 * (theta[:-1] @ theta[:-1]))


def local_update(theta: np.ndarray, X: np.ndarray, y: np.ndarray, cfg: FederationConfig,
                 rng: np.random.Generator) -> np.ndarray:
    if len(X) != len(y) or len(y) == 0 or X.shape[1] + 1 != len(theta):
        raise ValueError("Invalid local-training dimensions")
    weights = theta.copy()
    for _ in range(cfg.local_epochs):
        order = rng.permutation(len(y))
        for start in range(0, len(order), cfg.batch_size):
            idx = order[start:start + cfg.batch_size]
            weights -= cfg.learning_rate * gradient(weights, X[idx], y[idx], cfg.l2)
    if not np.all(np.isfinite(weights)):
        raise FloatingPointError("Local optimizer diverged; inspect the logged configuration")
    return weights - theta
