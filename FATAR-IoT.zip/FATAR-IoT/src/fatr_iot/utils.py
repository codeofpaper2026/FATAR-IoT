"""Deterministic random streams, safe serialization and provenance helpers."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import platform
import sys
from pathlib import Path
from typing import Any

import numpy as np


def rng_for(seed: int, *stream: int) -> np.random.Generator:
    """Method-independent streams: never use Python's randomized hash()."""
    return np.random.default_rng(np.random.SeedSequence([int(seed), *map(int, stream)]))


def seed_for(seed: int, *stream: int) -> int:
    return int(rng_for(seed, *stream).integers(0, 2**32 - 1))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, np.ndarray):
        return json_safe(value.tolist())
    if isinstance(value, np.generic):
        return json_safe(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    if isinstance(value, Path):
        return str(value)
    return value


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(json_safe(value), indent=2, sort_keys=True, allow_nan=False) + "\n", encoding="utf-8")


def environment() -> dict:
    packages = {}
    for name in ("numpy", "pandas", "scipy", "scikit-learn", "PyYAML", "threadpoolctl", "matplotlib"):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = "not installed"
    return {
        "python": sys.version.split()[0], "system": platform.system(),
        "release": platform.release(), "machine": platform.machine(),
        "processor": platform.processor(), "packages": packages,
    }


def source_fingerprint() -> dict:
    """Hashes source content, without exposing a local filesystem or a user name."""
    root = Path(__file__).parent
    hashes = {p.name: sha256_file(p) for p in sorted(root.glob("*.py"))}
    digest = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()
    return {"sha256": digest, "files": hashes}
