"""Explicit, bounded official-source retrieval; never silently fetch during training."""
from __future__ import annotations
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError
import csv
import io
import shutil
import zipfile
from .utils import sha256_file, write_json

RT_URL = "https://archive.ics.uci.edu/static/public/942/rt-iot2022.zip"
RT_PAGE = "https://archive.ics.uci.edu/dataset/942/rt-iot2022"


def fetch_rt_iot2022(output: Path, expected_sha256: str | None = None,
                    local_archive: Path | None = None) -> Path:
    """Record observed SHA256. Optional trusted expected hash fails closed on mismatch."""
    output.mkdir(parents=True, exist_ok=True)
    destination = output / "RT_IOT2022.csv"
    if destination.exists():
        raise FileExistsError(f"Refusing to replace {destination}")
    archive_path = local_archive or output / "rt-iot2022.zip"
    if local_archive is None:
        if archive_path.exists():
            raise FileExistsError("Archive already exists; use --archive to inspect it explicitly")
        part = output / "rt-iot2022.zip.partial"
        request = Request(RT_URL, headers={"User-Agent": "FATR-IoT-research-reference/0.1.0"})
        try:
            with urlopen(request, timeout=60) as response, part.open("xb") as handle:
                size = 0
                while block := response.read(1024 * 1024):
                    size += len(block)
                    if size > 100 * 1024 * 1024:
                        raise ValueError("Unexpected archive size (>100 MiB)")
                    handle.write(block)
            part.rename(archive_path)
        except (URLError, OSError, ValueError) as exc:
            part.unlink(missing_ok=True)
            raise RuntimeError("Official UCI download failed. Download the archive from the dataset page and rerun with --archive PATH.") from exc
    digest = sha256_file(archive_path)
    if expected_sha256 and digest.lower() != expected_sha256.lower():
        raise ValueError("SHA256 mismatch: do not use this archive")
    with zipfile.ZipFile(archive_path) as archive:
        candidates = []
        for info in archive.infolist():
            if info.is_dir() or info.file_size > 200 * 1024 * 1024 or info.filename.startswith("__MACOSX/"):
                continue
            with archive.open(info) as handle:
                first = handle.readline(32768).decode("utf-8-sig", errors="replace")
            if "Attack_type" in next(csv.reader(io.StringIO(first)), []):
                candidates.append(info)
        if len(candidates) != 1:
            raise ValueError("Expected exactly one original RT-IoT2022 CSV with Attack_type; inspect the archive")
        selected = candidates[0]
        # Copy to our own fixed filename. Never extract arbitrary archive paths.
        temporary = output / "RT_IOT2022.csv.partial"
        try:
            with archive.open(selected) as src, temporary.open("xb") as dst:
                shutil.copyfileobj(src, dst)
            temporary.rename(destination)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
    write_json(output / "download_manifest.json", {
        "dataset": "RT-IoT2022", "landing_page": RT_PAGE, "download_url": RT_URL,
        "doi": "10.24432/C5P338", "authors": "B. S. Sharmila; Rohini Nagapadma",
        "license": "CC-BY-4.0", "license_url": "https://creativecommons.org/licenses/by/4.0/",
        "archive_sha256": digest, "expected_sha256_verified": bool(expected_sha256),
        "csv_sha256": sha256_file(destination), "archive_member": selected.filename,
        "modifications": "CSV bytes copied unchanged; later preparation is a separately documented derivative",
        "attribution": "S., B. & Nagapadma, R. (2023). RT-IoT2022 [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5P338",
    })
    return destination
