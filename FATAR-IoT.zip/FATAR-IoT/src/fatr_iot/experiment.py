"""Matched-seed FL runner. Saved outputs are newly measured reference results."""
from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import time
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_info, threadpool_limits
from .aggregation import Aggregator
from .attacks import attack_active, poison_labels, poison_update
from .config import ExperimentConfig
from .data import PreparedData, load_raw, prepare_data
from .metrics import binary_metrics, calibrate_threshold
from .model import local_update, probability
from .partition import dirichlet_partition
from .utils import environment, rng_for, source_fingerprint, write_json


def _make_clients(data: PreparedData, cfg: ExperimentConfig, seed: int, partitions: list[np.ndarray]) -> list[tuple[np.ndarray, np.ndarray]]:
    X, y = data.arrays["train_X"], data.arrays["train_y"]
    f = cfg.federation
    clients = []
    for i, idx in enumerate(partitions):
        local_X = X[idx].copy()
        # Fixed client-specific perturbations of training features, off by default.
        rng = rng_for(seed, 30, i)
        scale = np.exp(rng.normal(0, f.feature_scale_std, size=X.shape[1]))
        bias = rng.normal(0, f.feature_bias_std, size=X.shape[1])
        local_X = local_X * scale + bias + rng.normal(0, f.feature_noise_std, size=local_X.shape)
        clients.append((local_X, y[idx].copy()))
    return clients


def run_one(data: PreparedData, clients: list[tuple[np.ndarray, np.ndarray]], malicious_ids: np.ndarray,
            cfg: ExperimentConfig, seed: int, method: str, attack: str, output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=False)
    a, f = data.arrays, cfg.federation
    theta = np.zeros(a["train_X"].shape[1] + 1, dtype=np.float64)
    sizes = np.asarray([len(y) for _, y in clients], dtype=np.int64)
    bound = cfg.baselines.krum_byzantine_bound
    if bound is None:
        bound = len(malicious_ids)
    aggregator = Aggregator(method, f.clients, len(theta), cfg.fatr, cfg.baselines, bound)
    malicious_mask = np.isin(np.arange(f.clients), malicious_ids)
    round_rows, client_rows, history = [], [], []
    threshold = 0.5
    for round_number in range(1, f.rounds + 1):
        start_total = time.perf_counter()
        active = attack != "none" and attack_active(round_number, cfg.attack)
        start_training = time.perf_counter()
        updates = []
        for client_id, (X, y) in enumerate(clients):
            train_y = y
            if active and malicious_mask[client_id] and attack == "label_flip":
                train_y = poison_labels(y, cfg.attack.label_flip_fraction, rng_for(seed, 40, client_id))
            delta = local_update(theta, X, train_y, f, rng_for(seed, 50, round_number, client_id))
            if active and malicious_mask[client_id]:
                delta = poison_update(delta, attack, cfg.attack, rng_for(seed, 60, round_number, client_id))
            updates.append(delta)
        training_seconds = time.perf_counter() - start_training
        start_aggregation = time.perf_counter()
        delta, diagnostics = aggregator.aggregate(np.asarray(updates), sizes, theta, a["reference_X"])
        theta += f.server_learning_rate * delta
        if not np.isfinite(theta).all():
            raise FloatingPointError("Nonfinite global model")
        aggregation_seconds = time.perf_counter() - start_aggregation
        start_calibration = time.perf_counter()
        calibration_scores = probability(theta, a["calibration_X"])
        threshold = calibrate_threshold(calibration_scores, cfg.target_fpr)
        calibration_fpr = float(np.mean(calibration_scores > threshold))
        calibration_seconds = time.perf_counter() - start_calibration
        start_evaluation = time.perf_counter()
        test_scores = probability(theta, a["test_X"])
        metrics = binary_metrics(a["test_y"], test_scores, threshold)
        validation_metrics = binary_metrics(a["validation_y"], probability(theta, a["validation_X"]), threshold) if len(a["validation_y"]) else {}
        evaluation_seconds = time.perf_counter() - start_evaluation
        row = {"seed": seed, "method": method, "attack": attack, "round": round_number,
               "threshold": threshold, "target_fpr": cfg.target_fpr, "calibration_fpr": calibration_fpr,
               "attack_active": active, "active_byzantine_clients": int(malicious_mask.sum()) if active else 0,
               "invalid_clients": int(np.sum(~diagnostics["valid"])), "fallback": diagnostics["fallback"],
               "training_seconds": training_seconds, "aggregation_seconds": aggregation_seconds,
               "calibration_seconds": calibration_seconds, "evaluation_seconds": evaluation_seconds,
               "total_round_seconds": time.perf_counter() - start_total,
               "uplink_payload_bytes": int(f.clients * len(theta) * theta.dtype.itemsize), **metrics,
               **{f"validation_{k}": v for k, v in validation_metrics.items()}}
        if diagnostics["trust"] is not None:
            row["mean_honest_trust"] = float(aggregator.trust[~malicious_mask].mean())
            row["mean_assigned_byzantine_trust"] = float(aggregator.trust[malicious_mask].mean()) if malicious_mask.any() else None
        round_rows.append(row)
        if cfg.save_model_history:
            history.append(theta.copy())
        for i in range(f.clients):
            item = {"round": round_number, "client_id": i, "n": int(sizes[i]),
                    "assigned_byzantine": bool(malicious_mask[i]), "active_byzantine": bool(active and malicious_mask[i]),
                    "valid": bool(diagnostics["valid"][i])}
            for key in ("trust", "score", "drift", "drift_z", "alignment", "history_alignment",
                        "normalized_distance", "norm_penalty", "raw_norm", "clip_factor", "normalized_weight", "history_updated"):
                if diagnostics.get(key) is not None:
                    value = diagnostics[key][i]
                    item[key] = value.item() if isinstance(value, np.generic) else value
            client_rows.append(item)
    pd.DataFrame(round_rows).to_csv(output / "round_metrics.csv", index=False)
    pd.DataFrame(client_rows).to_csv(output / "client_diagnostics.csv", index=False)
    np.savez_compressed(output / "model.npz", theta=theta, threshold=np.asarray(threshold))
    if cfg.save_model_history:
        np.savez_compressed(output / "model_history.npz", theta=np.asarray(history), thresholds=np.asarray([x["threshold"] for x in round_rows]))
    write_json(output / "preprocessor.json", data.preprocessor)
    if cfg.save_predictions:
        predictions = pd.DataFrame({"row_id": a["test_ids"], "label": a["test_y"], "attack_type": a["test_groups"],
                                    "attack_probability": test_scores, "prediction": (test_scores > threshold).astype(int)})
        predictions.to_csv(output / "test_predictions.csv.gz", index=False, compression={"method": "gzip", "mtime": 0})
    groups = []
    for group in sorted(set(a["test_groups"])):
        idx = a["test_groups"] == group
        group_labels = a["test_y"][idx]
        if len(np.unique(group_labels)) != 1:
            raise ValueError("Attack group contains mixed benign/attack labels")
        positive_rate = float(np.mean(test_scores[idx] > threshold))
        groups.append({"attack_type": group, "label": int(group_labels[0]), "n": int(idx.sum()),
                       "recall": positive_rate if group_labels[0] == 1 else None,
                       "fpr": positive_rate if group_labels[0] == 0 else None})
    pd.DataFrame(groups).to_csv(output / "attack_type_metrics.csv", index=False)
    result = {"implementation_status": "new_reference_result_not_original_manuscript_result",
              "dataset": cfg.data.dataset, "selected_round_rule": "last configured round; no test-based checkpoint selection",
              "final": round_rows[-1], "attack_type_metrics": groups,
              "assigned_byzantine_client_ids": malicious_ids.tolist(), "effective_fatr_parameters": asdict(aggregator.cfg),
              "krum_byzantine_bound": bound, "model_parameters": len(theta)}
    write_json(output / "result.json", result)
    return result


def run_campaign(cfg: ExperimentConfig, config_directory: Path, output: Path) -> dict:
    cfg.validate()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"Refusing to overwrite nonempty output directory {output}")
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "resolved_config.json", asdict(cfg))
    write_json(output / "source_fingerprint.json", source_fingerprint())
    raw = load_raw(cfg.data, config_directory)
    results = []
    start = time.perf_counter()
    with threadpool_limits(limits=cfg.threads):
        env = environment()
        env["thread_limit"] = cfg.threads
        # Drop library binary paths from public provenance; retain versions/architecture.
        env["threadpools"] = [{k: v for k, v in p.items() if k != "filepath"} for p in threadpool_info()]
        write_json(output / "environment.json", env)
        for seed in cfg.seeds:
            seed_dir = output / f"seed_{seed}"
            data = prepare_data(raw, cfg.data, seed)
            data.save(seed_dir / "data")
            partitions, pinfo = dirichlet_partition(data.arrays["train_y"], cfg.federation.clients,
                cfg.federation.dirichlet_alpha, cfg.federation.minimum_client_size,
                cfg.federation.partition_retries, rng_for(seed, 20))
            write_json(seed_dir / "partition.json", pinfo)
            assignment = []
            for i, indices in enumerate(partitions):
                for j in indices:
                    assignment.append({"row_id": data.arrays["train_ids"][j], "client_id": i,
                                       "train_index": int(j), "label": int(data.arrays["train_y"][j])})
            pd.DataFrame(assignment).to_csv(seed_dir / "client_assignments.csv", index=False)
            n_bad = int(np.floor(cfg.attack.byzantine_fraction * cfg.federation.clients))
            malicious = np.sort(rng_for(seed, 21).choice(cfg.federation.clients, n_bad, replace=False))
            clients = _make_clients(data, cfg, seed, partitions)
            for attack in cfg.attacks:
                for method in cfg.methods:
                    result = run_one(data, clients, malicious, cfg, seed, method, attack, seed_dir / attack / method)
                    results.append(result)
                    final = result["final"]
                    print(f"seed={seed} attack={attack} method={method} F1={final['f1']:.5f} FPR={final['fpr']:.5f}", flush=True)
    report = {"status": "completed_new_reference_campaign", "dataset": cfg.data.dataset,
              "runs": len(results), "seeds": cfg.seeds, "rounds_per_run": cfg.federation.rounds,
              "elapsed_seconds": time.perf_counter() - start,
              "original_manuscript_metrics_reproduced": False}
    write_json(output / "campaign.json", report)
    return report
