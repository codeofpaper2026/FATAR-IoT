# FATR-IoT

**Benign-referenced temporal robust aggregation for federated intrusion detection.**

This repository contains a runnable Python implementation, a newly generated synthetic
dataset, public-dataset preparation tools, explicit configurations, unit/integration
tests, and scripts for generating local experiment outputs.

> **Research provenance:** version 0.1.0 is a **new reference implementation of the
> manuscript's mathematical design**, with documented choices for unspecified details.
> It is **not the unavailable original experiment implementation**. The bundled dataset
> and code do **not** reproduce the original manuscript's numerical tables.
> The original `TrustFedAvg` implementation remains unidentified; `geometry_trust`
> is a newly defined comparator and must not be relabeled as that method.

## Real-data experiments

The original RT-IoT2022 CSV and executable configurations are included. See
[run instructions](docs/RUN_REAL_DATA.md). Experiment results, trained models,
plots and logs are not distributed in this package.

## What is included

| Component | Contents |
|---|---|
| FATR | Median/MAD clipping, median geometry, own-client EMA history, benign prediction drift, smoothed trust, size-weighted aggregation |
| Baselines | FedAvg, coordinate median, coordinate trimmed mean, single-Krum, and a disclosed geometry-only trust comparator |
| Ablations | No benign drift, no history, no clipping, and no trust smoothing |
| Conditions | No poisoning, sign-flip, Gaussian update noise, label-flip, and positive update scaling |
| Model | Explicit float64 binary logistic regression with mini-batch SGD |
| Data | **30,000 newly generated synthetic examples**, 20 numerical features, binary labels, stable row IDs, and one prepared split |
| Public data | Original UCI RT-IoT2022 CSV (CC BY 4.0), adapter and executable configurations; UNSW-NB15 adapter only |
| Reporting | Split/client IDs, resolved settings, source hashes, per-round/client logs, final predictions, model states, seed means/sample SDs, and paired exploratory intervals |

The package is a local single-process simulator, **not** a production FL service.
It does not implement secure aggregation, differential privacy, enrollment security,
or a guarantee on future false-positive rates. See [method details](docs/METHOD.md)
and [scope and privacy](SECURITY.md).

## Install

Python 3.13 is the tested interpreter. The project declares Python 3.11 or newer.
Run commands from this repository's root directory.

**Windows PowerShell** â€” activation is not required:

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.lock.txt
.\.venv\Scripts\python.exe -m pip install --no-deps -e .
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m fatr_iot run --config configs/synthetic.yaml --output outputs/demo
```

**Linux / macOS:**

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.lock.txt
python -m pip install --no-deps -e .
python -m pytest -q
python -m fatr_iot run --config configs/synthetic.yaml --output outputs/demo
```

`requirements.lock.txt` records exact versions used in the available validation
environment. Editable installation and the test suite were executed there; an
internet-based dependency installation into an otherwise empty environment was not
possible in that environment. CI is provided to repeat the checks on GitHub; it has
not yet been executed on your GitHub account.

## Run experiments

The default experiment uses 20 clients, 30 rounds, one local epoch, four assigned
Byzantine clients, a 5% empirical calibration target, and five explicitly defined
methods. **All numerical defaults are reference choices**, not recovered paper settings.

```bash
# Five methods, seed 42, 30 rounds, sign-flip poisoning.
python -m fatr_iot run --config configs/synthetic.yaml --output outputs/demo

# Five attack conditions, six methods and five paired seeds: 150 new runs.
python -m fatr_iot run --config configs/synthetic_benchmark.yaml --output outputs/benchmark

# Component ablations across five conditions and five paired seeds.
python -m fatr_iot run --config configs/ablations.yaml --output outputs/ablations

# Two-round execution check of all 10 methods and 5 conditions; not a benchmark.
python -m fatr_iot run --config configs/smoke.yaml --output outputs/smoke

# Run a 15-run, 30-round synthetic validation configuration.
python -m fatr_iot run --config configs/validation_run.yaml --output outputs/validation

# Override a configuration without editing its source; overrides are logged.
python -m fatr_iot run --config configs/synthetic.yaml --output outputs/custom --seeds 4 5 6 --methods fatr median --attacks none sign_flip

python -m fatr_iot summarize --input outputs/benchmark
python -m fatr_iot plot --input outputs/benchmark
```

Commands refuse to overwrite a nonempty output directory. Test metrics are logged
for analysis only: the final configured round is the reported checkpoint, and no
threshold, parameter, or model selection uses test labels. Model initialization,
partitions, client selection, local shuffles and attack random streams are paired
across methods. Different methods can legitimately produce different results.

### Datasets

The synthetic CSV is already included, so the default experiment requires no data
download. To generate a separate dataset or recreate the prepared example:

```bash
python -m fatr_iot generate --output data/new_synthetic --samples 30000 --seed 42
python -m fatr_iot prepare --config configs/synthetic.yaml --seed 42 --output outputs/prepared_seed42
```

RT-IoT2022 is already bundled. Run the benchmark directly; fetch is only needed if the raw CSV is absent:

```bash
python -m fatr_iot run --config configs/rt_iot2022.yaml --output outputs/rt_iot2022 --plots
```

The download is explicit, uses the official UCI address, records SHA-256 hashes and
attribution, and supports a supplied expected hash. It is not silently run by training.
The unchanged RT-IoT2022 CSV from UCI is included. No experiment outputs or
UNSW-NB15 observations are distributed. Adapter unit tests use invented schema fixtures.
UNSW-NB15 requires the custodian's original training/testing CSVs in
`data/raw/unsw_nb15/`. See [dataset instructions and rights](docs/DATASETS.md).

### Outputs and inference

Every completed method/seed/condition folder contains `result.json`,
`round_metrics.csv`, `client_diagnostics.csv`, `attack_type_metrics.csv`,
`model.npz`, `preprocessor.json`, and, by default, model history and compressed test
predictions. At the campaign root, inspect `summary.csv`, `final_per_run.csv`,
`paired_differences.csv`, `resolved_config.json`, and `source_fingerprint.json`.

```bash
python -m fatr_iot predict --model-dir outputs/demo/seed_42/sign_flip/fatr --csv data/synthetic/synthetic_v1.csv.gz --output outputs/predictions.csv
```

The prediction command demonstrates safe model loading and local scoring. Scoring
the full synthetic CSV is **not** an unbiased test evaluation; use saved held-out
`test_predictions.csv.gz` for that purpose. Saved models use NPZ arrays with
`allow_pickle=False` and JSON preprocessing state.

## Repository layout

```text
fatr-iot/
  src/fatr_iot/           # Model, aggregation, data, attacks, metrics, runner and CLI
  configs/               # Explicit, inheritable YAML configurations
  data/synthetic/        # New synthetic_v1.csv.gz, generator manifest and data card
  data/example_split/    # Prepared arrays, row assignments, preprocessing and manifest
  data/raw/              # RT-IoT2022 CSV + attribution; UNSW instructions only
  tests/                 # Numerical, leakage, reproducibility and end-to-end tests
  docs/                  # Method, datasets, reproducibility and GitHub upload guide
  scripts/               # Convenience launchers and release-integrity checker
  .github/workflows/     # Minimal-permission CI
```

## Citation and publication use

Use `CITATION.cff` for this software and the original dataset citations for any
public data you use. The associated manuscript is *Benign-Referenced Temporal Robust
Aggregation for Byzantine-Resilient Federated IoT Intrusion Detection*. This release
does not assert that the manuscript has been accepted or published and invents no
DOI or public repository address. See [manuscript alignment](docs/MANUSCRIPT_ALIGNMENT.md).

The MIT license covers the newly authored code, documentation and synthetic data.
Third-party datasets retain their own licenses; those rights are not replaced by
this repository's license. Review institutional/coauthor release approval before
publishing. Instructions for publishing the folder are in
[docs/GITHUB_UPLOAD.md](docs/GITHUB_UPLOAD.md).
