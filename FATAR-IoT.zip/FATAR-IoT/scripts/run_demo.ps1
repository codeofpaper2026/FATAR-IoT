$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
$Python = if (Test-Path ".venv\Scripts\python.exe") { ".venv\Scripts\python.exe" } else { "python" }
& $Python -m fatr_iot run --config configs/synthetic.yaml --output outputs/demo @args
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
