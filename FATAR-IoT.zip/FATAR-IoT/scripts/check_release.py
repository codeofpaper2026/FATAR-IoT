"""Verify the bundled source/data snapshot against SHA256SUMS.txt.

Hashes are a snapshot-integrity aid, not a signature or proof of source authenticity.
"""
from pathlib import Path
import hashlib
import sys

root = Path(__file__).resolve().parents[1]
manifest = root / "SHA256SUMS.txt"
if not manifest.exists():
    raise SystemExit("Missing SHA256SUMS.txt")
errors = []
count = 0
for line in manifest.read_text(encoding="utf-8").splitlines():
    if not line or line.startswith("#"):
        continue
    expected, filename = line.split("  ", 1)
    path = (root / filename).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        errors.append(f"Missing or unsafe path: {filename}")
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    # Git may normalize CRLF on Windows; canonical text bytes use LF for text files.
    if digest != expected and path.suffix.lower() in {".py", ".md", ".txt", ".json", ".csv", ".yaml", ".yml", ".cff", ".toml", ".ps1", ".sh"}:
        digest = hashlib.sha256(path.read_bytes().replace(b"\r\n", b"\n")).hexdigest()
    if digest != expected:
        errors.append(f"Hash mismatch: {filename}")
    count += 1
if errors:
    print("\n".join(errors), file=sys.stderr)
    raise SystemExit(1)
print(f"Verified {count} bundled files.")
