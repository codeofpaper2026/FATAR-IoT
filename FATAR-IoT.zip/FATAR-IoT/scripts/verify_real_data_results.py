"""Verify a locally generated 150-run RT-IoT2022 campaign without retraining."""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

def verify(folder):
    files = sorted(folder.glob('seed_*/*/*/result.json'))
    if len(files) != 150:
        raise ValueError(f'Expected 150 completed runs, found {len(files)}')
    records = [json.loads(f.read_text(encoding='utf-8')) for f in files]
    if any(r['dataset'] != 'rt_iot2022' for r in records):
        raise ValueError('Unexpected dataset')
    rows = pd.DataFrame([r['final'] for r in records])
    methods = {'fedavg', 'median', 'trimmed_mean', 'krum', 'geometry_trust', 'fatr'}
    attacks = {'none', 'sign_flip', 'gaussian', 'label_flip', 'scaling'}
    expected = {(s, a, m) for s in [11,22,33,44,55] for a in attacks for m in methods}
    if set(zip(rows.seed, rows.attack, rows.method)) != expected or rows.duplicated(['seed','attack','method']).any():
        raise ValueError('Missing or duplicate seed/attack/method combination')
    if not (rows['round'] == 30).all():
        raise ValueError('Expected final round 30')
    np.testing.assert_allclose(rows.f1, 2*rows.tp/(2*rows.tp+rows.fp+rows.fn),rtol=1e-12)
    np.testing.assert_allclose(rows.fpr, rows.fp/(rows.fp+rows.tn),rtol=1e-12)
    table = pd.read_csv(folder/'summary.csv')
    if len(table)!=30 or table.duplicated(['attack','method']).any():
        raise ValueError('Expected 30 unique summary groups')
    if set(zip(table.attack,table.method)) != {(a,m) for a in attacks for m in methods}:
        raise ValueError('Incorrect summary combinations')
    for row in table.itertuples():
        group=rows[(rows.method==row.method)&(rows.attack==row.attack)]
        if row.n_runs!=5: raise ValueError('Expected five replicates')
        for metric in ['accuracy','precision','recall','f1','auc','average_precision','fpr','mcc']:
            values=group[metric].dropna()
            np.testing.assert_allclose([getattr(row,metric+'_mean'),getattr(row,metric+'_sample_sd')],
                                       [values.mean(),values.std(ddof=1)],rtol=1e-10,atol=1e-14,equal_nan=True)
    for seed in [11,22,33,44,55]:
        manifest=json.loads((folder/f'seed_{seed}/data/manifest.json').read_text())
        if any(manifest['cross_split_feature_hash_overlaps'].values()):
            raise ValueError('Feature leakage between splits')
        ids=pd.read_csv(folder/f'seed_{seed}/data/split_ids.csv')
        if len(ids)!=117915 or ids['row_id'].duplicated().any():
            raise ValueError('Invalid or duplicate split IDs')
    raw=ROOT/'data/raw/rt_iot2022'
    manifest=json.loads((raw/'download_manifest.json').read_text())
    if hashlib.sha256((raw/'RT_IOT2022.csv').read_bytes()).hexdigest()!=manifest['csv_sha256']:
        raise ValueError('Raw dataset hash mismatch')
    fingerprint=json.loads((folder/'source_fingerprint.json').read_text())['files']
    for name,digest in fingerprint.items():
        content=(ROOT/'src/fatr_iot'/name).read_bytes()
        if hashlib.sha256(content).hexdigest()!=digest and hashlib.sha256(content.replace(b'\r\n',b'\n')).hexdigest()!=digest:
            raise ValueError(f'Implementation differs from recorded campaign: {name}')
    print('Verified 150 runs, 30 mean/SD groups, all split IDs, original dataset and implementation hashes.')

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,required=True,help='Path to your generated RT-IoT2022 campaign')
    args=parser.parse_args()
    verify(args.input.resolve())
