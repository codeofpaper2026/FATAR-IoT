#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python -m fatr_iot run --config configs/synthetic.yaml --output outputs/demo "$@"
