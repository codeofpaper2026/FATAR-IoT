# Reproducibility and interpretation

## Replay inputs

A run is defined by the source code hash, dependency versions, raw dataset hash,
resolved YAML, seed and machine/thread configuration. `source_fingerprint.json`
hashes every implementation module; `environment.json` records Python and libraries
without embedding local binary paths. `data/*/manifest.json` records the raw file
hashes, row counts, transformations and split overlap checks.

The software defaults to a single numerical-library thread via `threadpoolctl`.
Floating-point results can still differ slightly across platforms or dependency
versions. Timing values are expected to vary and are not deterministic evidence of
edge-device performance. Training, server aggregation, threshold calibration and
evaluation timers cover explicitly distinct regions. Total round time includes
these regions and bookkeeping, but not file serialization after training. Client
training is sequential in this simulator, not real parallel wall-clock federation.

The update payload count is `clients * parameter_count * 8` bytes for float64,
excluding transport, encoding, metadata, retransmission and downlink. With 20
features and an intercept, an individual update has 21 parameters (168 bytes).
The original manuscript mentioned float32 payloads; this implementation's dtype
is an explicit, different reference choice.

## Random streams and non-IID allocation

NumPy `SeedSequence` receives `[experiment_seed, stream_id, ...]`. No stream uses
Python's process-randomized `hash()` or method order. Stream IDs are fixed in source:
10/11 for data splitting (derived scikit-learn seeds), 12 for benign-buffer draws,
20 for client partitioning, 21 for attacker IDs, 30 for optional feature shifts,
40 for label-flip rows, 50 for local shuffles and 60 for update noise.

For each label, draw a `Dirichlet(alpha,...,alpha)` vector across clients, then
multinomial counts and randomly assigned rows. Reject the **whole draw** when any
client has fewer than the configured minimum; retry at most 1,000 times. No hidden
post-hoc row transfer repairs the skew. The actual draw count, probabilities, class
histograms and row-to-client assignment are written to disk. The default concentration
is 0.5, minimum size is 10, and participation is full.

Optional per-client lognormal scale, additive bias and per-row Gaussian perturbations
are fixed for the seed and applied only to training features after shared preprocessing.
All three default standard deviations are zero. They are a controlled training
covariate shift, not an observed device distribution or a claim to match the original
paper's unspecified transformations.

## Repeated runs and statistics

`summary.csv` contains final-round means and **sample** standard deviations (`ddof=1`)
over independent seeded reruns on a fixed dataset. One-seed standard deviations are
missing, not zero. The five-seed campaign uses [11,22,33,44,55]; the synthetic validation
configuration uses [11,22,33]. It varies splits, partitions and training streams,
not the raw synthetic generator. This estimates conditional run-to-run variability,
not uncertainty across different real organizations or datasets.

`paired_differences.csv` joins method results by seed, then resamples paired
seed-level differences 5,000 times for exploratory percentile intervals. FPR and
F1 are not pooled across unrelated poisoning conditions. These intervals can be
unreliable with very few seeds; there is no multiplicity correction and no implied
claim of statistically established superiority. Longitudinal round variation is
never treated as independent replication.

The held-out decision rule is `score > threshold`; ties are benign. Precision,
recall, FPR, F1 and MCC are calculated from binary confusion counts, AUROC from
continuous attack probabilities, and average precision from continuous scores.
Undefined denominators and one-class AUROC produce missing values rather than
fabricated metrics. Category rows report attack recall or benign FPR as appropriate.

## Test coverage

The automated tests cover analytic gradients, extreme sigmoid inputs, clipping,
median/trimmed-mean/Krum behavior, zero/nonfinite vectors, trust/history updates,
zero-weight fallback, exact threshold tie semantics, disjoint splits, preprocessing
fit scope, categorical unknowns, dataset schema adapters, safe archive extraction,
partition completeness, method-order invariance, paired summaries and model reload.
A test passing does not prove Byzantine resilience or reference-set integrity.

The downloader's network path and full public-data pipelines were **not** executed
successfully in the preparation environment. The downloader and loaders have fixture
coverage only. New public-dataset experiments remain necessary. The source lock
records available tested versions; a fresh online installation remains to be checked
by CI or the maintainer.

## Local outputs

Experiment outputs are generated locally and are not bundled. Run the selected
configuration, then summarize or plot your own output directory. For the complete
RT-IoT2022 campaign, use scripts/verify_real_data_results.py --input PATH to check
confusion-count metrics, sample SDs, split IDs, and source/data hashes.
