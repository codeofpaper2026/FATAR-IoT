# Primary references

The code is newly authored from mathematical descriptions and documented reference
choices; third-party implementations are not vendored.

- McMahan, B., et al. (2017). Communication-Efficient Learning of Deep Networks
  from Decentralized Data. AISTATS/PMLR 54, 1273–1282.
  https://proceedings.mlr.press/v54/mcmahan17a.html
- Blanchard, P., El Mhamdi, E. M., Guerraoui, R., & Stainer, J. (2017).
  Machine Learning with Adversaries: Byzantine Tolerant Gradient Descent. NeurIPS 30.
  https://papers.nips.cc/paper_files/paper/2017/hash/f4b9ec30ad9f68f89b29639786cb62ef-Abstract.html
- Yin, D., Chen, Y., Ramchandran, K., & Bartlett, P. (2018).
  Byzantine-Robust Distributed Learning: Towards Optimal Statistical Rates. ICML/PMLR 80.
  https://proceedings.mlr.press/v80/yin18a.html
- Hsu, T. M. H., Qi, H., & Brown, M. (2019). Measuring the Effects of Non-Identical
  Data Distribution for Federated Visual Classification. https://arxiv.org/abs/1909.06335
- S., B. & Nagapadma, R. (2023). RT-IoT2022 [Dataset]. UCI Machine Learning Repository.
  https://doi.org/10.24432/C5P338
- Sharmila, B. S. & Nagapadma, R. (2023). Quantized autoencoder (QAE) intrusion
  detection system for anomaly detection in resource-constrained IoT devices using
  RT-IoT2022 dataset. Cybersecurity 6, 41. https://doi.org/10.1186/s42400-023-00178-5
- Moustafa, N. & Slay, J. (2015). UNSW-NB15: A comprehensive data set for network
  intrusion detection systems. MilCIS. https://doi.org/10.1109/MilCIS.2015.7348942

Follow **all citation requirements on the UNSW custodian's current page** when using
that dataset; the short reference list here does not replace those requirements.

Implementation documentation consulted:

- Scikit-learn generator: https://scikit-learn.org/stable/modules/generated/sklearn.datasets.make_classification.html
- Training/test leakage guidance: https://scikit-learn.org/stable/common_pitfalls.html
- NumPy deterministic stream construction: https://numpy.org/doc/stable/reference/random/parallel.html
- GitHub upload instructions: https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github
