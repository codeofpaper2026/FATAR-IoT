# Executable FATR reference specification

This specification fixes the degrees of freedom left unspecified in the supplied
manuscript. It documents version 0.1.0, **not** the unknown configuration behind the
paper's previous results. All operations use float64, including the bias parameter.

## Local training and federation

Each client receives the same global parameter vector `theta=[w,b]` and minimizes
mean binary logistic loss plus `(l2/2)*||w||^2`; the intercept is not regularized.
Plain mini-batch SGD uses one epoch, batch size 64, constant learning rate 0.05 and
`l2=1e-4`. No momentum, optimizer state, class weighting, resampling, feature
selection or hidden tuning is used. Weights and intercept initialize to zero.
A client sends `local_theta - global_theta`. All 20 clients participate every round.
Verified local row counts are used wherever an aggregation method needs weights.
The server learning rate is 1.0. The configured final round is reported.

## FATR round, in execution order

Write `u_i` for the raw received vector. The server inspects every client vector;
this cannot be executed with an ordinary sum-only secure-aggregation interface.

1. Reject nonfinite vectors or vectors with any absolute coordinate above `1e100`.
   This common numerical guard is applied to **all** methods. Rejected FATR clients
   receive zero trust and no history update. The guard is not a Byzantine guarantee.
2. For valid clients, compute `r_i=||u_i||_2`, `m=median(r)` and
   `MAD_r=median(|r-m|)`. The clipping cap is `m+2.5*MAD_r` with raw MAD, without a
   normal consistency factor. Set `v_i=u_i*min(1,cap/max(r_i,epsilon))`. If both the
   norm median and MAD are zero, the cap is zero. The no-clipping ablation uses
   `v_i=u_i` but retains the other norm/distance penalties.
3. Compute the coordinate median `v_med` **after** clipping. Even-sized medians
   use the average of the two central values. Set
   `d_i=||v_i-v_med||/max(median_j||v_j-v_med||,epsilon)` and cap it at 100.
4. Compute `cos(v_i,v_med)` and `cos(v_i,H_i)`. Cosine is zero whenever either
   operand has norm at most `epsilon`. Histories initially equal zero.
5. Compute signed benign drift
   `D_i=mean_x[p(theta+v_i,x)-p(theta,x)]` on the trust-reference split. A candidate
   is evaluated before the separate server step-size multiplier, which is 1 here.
   Set `z_i=(D_i-median(D))/max(1.4826*median(|D-median(D)|),1e-6)` and cap `z_i`
   to `[-10,10]`. A zero drift coefficient skips reference scoring entirely.
6. The norm penalty uses **raw**, not clipped, norms:
   `phi_i=clip(r_i/max(m,epsilon)-1,0,100)`. It penalizes above-median magnitude,
   not small or zero updates symmetrically.
7. The composite score is
   `s_i=2*cos(v_i,v_med)+1*cos(v_i,H_i)-1*d_i-1*abs(z_i)-0.5*phi_i`.
   Update `tau_i=0.8*tau_i+0.2*sigmoid(s_i)` with initial trust 0.5.
8. Compute `delta=sum_i(tau_i*n_i*v_i)/sum_i(tau_i*n_i)`. If the sum of weights
   is at most `1e-12`, use the clipped coordinate median. If every client is
   numerically invalid, do not update the global model.
9. For clients whose updated trust is at least 0.5, update
   `H_i=0.8*H_i+0.2*v_i`. Other histories remain frozen. The no-history variants
   skip the history operation entirely. There is no churn, identity reset, or
   history expiration in this version.
10. Set `theta=theta+server_learning_rate*delta` and recalibrate the decision
    threshold on the separate benign calibration split.

The constants above are declared in `configs/base.yaml`. Changing any of them
creates a different executable specification. The numerical guard, clipping,
score saturation and fallback rules are all substantive choices, not implicit
proofs inherited from robust estimators.

## Baseline identities and ablations

| Identifier | Exact implementation |
|---|---|
| `fedavg` | Sample-count-weighted mean of valid raw updates; no norm clipping |
| `median` | Unweighted coordinate median of valid raw updates |
| `trimmed_mean` | Sort each coordinate; discard `floor(0.2*n_valid)` from each tail; unweighted mean of retained coordinates |
| `krum` | Single-Krum squared-distance selection with `n-f-2` other neighbors; lowest client index breaks ties; no extra clipping |
| `geometry_trust` | Same reference clipping/geometry/norm/trust smoothing as FATR, but both history and benign-drift coefficients are zero |
| `fatr` | Full specification above |
| `fatr_no_drift` | Full FATR with benign-drift coefficient zero |
| `fatr_no_history` | Full FATR with history coefficient zero and no history state updates |
| `fatr_no_clipping` | Full FATR without norm clipping, retaining norm and geometry penalties |
| `fatr_no_smoothing` | Full FATR with trust EMA coefficient zero |

`geometry_trust` is a new comparator. It is **not FLTrust**, does not use a root
training gradient, and is **not the manuscript's unidentified TrustFedAvg**.
The other methods instantiate their stated estimator families; there is no claim
that all implementation details match any third-party library.

Krum's corruption bound is explicit, defaulting to the configured number of
Byzantine clients even in the no-poisoning control. It requires `n_valid>2*f+2`;
if this fails after numerical rejections, it uses a logged no-update fallback.
All methods have identical raw training data, local training budgets, seeded
stochastic streams and calibration access. Only methods with a drift term inspect
the separate trust-reference features during aggregation. No parameters have been
tuned to match the original table or to ensure that FATR wins.

## Calibration

Let sorted calibration attack probabilities be `q_1<=...<=q_n` and
`a=floor(n*target_fpr)`. The threshold is `q_(n-a)` in one-based notation.
A sample is predicted to be an attack exactly when its score is **strictly greater**
than that threshold. Ties are benign. This ensures at most `a` false positives on
that finite calibration buffer, but it does **not** constrain test/production FPR.
The same empirical target (0.05 by default) is used for every method.

By default the trust reference and calibration split are disjoint. The
`shared_buffer.yaml` configuration deliberately reuses exactly the same benign
rows and marks that reuse in its manifest. This is an optional design study,
not an assertion about the unknown original split.

## Simulated poisoning

Attacker IDs are sampled once per seed, shared across methods and conditions, and
remain persistent. The number is `floor(20*0.2)=4` by default. Round indices start
at one; attacks are active from `start_round` through optional `end_round` inclusive.
The no-poisoning control keeps the assignment for pairing but activates no attackers.

| Condition | Mathematical action |
|---|---|
| `none` | No corruption |
| `sign_flip` | Send `-5*delta` |
| `gaussian` | Add independent Gaussian coordinate noise with SD `2*||delta||/sqrt(parameter_count)` |
| `label_flip` | Flip all local binary labels before training; the selected poisoned rows stay fixed across rounds |
| `scaling` | Send `10*delta`, preserving direction |

These are local simulation operations, not network intrusion generators. They do
not implement adaptive attacker optimization, targeted backdoors, sybil enrollment,
server/reference compromise, or poisoning that requires additional attacker data.
Network attack categories in a dataset and FL poisoning conditions are different axes.
