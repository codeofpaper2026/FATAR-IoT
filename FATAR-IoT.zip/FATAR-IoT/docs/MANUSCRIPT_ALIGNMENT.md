# Relationship to the manuscript

Associated manuscript: *Benign-Referenced Temporal Robust Aggregation for
Byzantine-Resilient Federated IoT Intrusion Detection*, by Omar A. Alzubi,
Hussam Fakhouri, Jafar A. Alzubi, Feras M. Awaysheh, and Sandi N. Fakhouri.

The supplied six-page manuscript specifies the composite mathematical structure but
explicitly reports missing original implementation settings. This code was written
from that specification; it is not an extraction of hidden or supplied training code.

| Manuscript information | Treatment in this release |
|---|---|
| Median geometry, norm clipping, benign drift, within-client history and trust EMA | Implemented with the disclosed structure |
| 20 synthetic features, logistic model, 20 clients, 30 rounds, one local epoch | Retained as reference-scenario dimensions |
| FPR target 0.05 and 1,200 benign reference samples | Retained; separate calibration buffer is a new default |
| Original generator, training size, seed, transformations, optimizer details | Unavailable; replaced by fully documented **new** choices |
| FATR coefficients, norm penalty, initialization, safeguards, gates | Unavailable; explicitly defined in METHOD.md and YAML |
| Original TrustFedAvg comparator | Not recovered; not claimed to be implemented |
| New geometry_trust comparator | Defined here; must not be presented as the old TrustFedAvg |
| Original table and figure values | Not generated or validated by this code |
| RT-IoT2022 | Original public CSV and runnable configurations; experiment outputs are not distributed |
| UNSW-NB15 | Retrieval/preparation support only; no observations or measured results |

To base a revised empirical paper on this package, identify the new code version,
replace the experimental description with its exact settings, execute the intended
campaign, retain all outputs, and regenerate every table/figure from those outputs.
Do not claim that releasing this code retroactively makes the original result table
reproducible. Do not state that public-dataset evaluation was performed simply because
the repository supports those datasets.

A truthful current availability statement, **after publishing the repository and
inserting its real location/version**, would be:

> A new reference implementation, a synthetic benchmark generator, an example
> dataset, dataset-preparation tools and tests are available
> in the accompanying software release. Unspecified implementation details have been
> explicitly fixed for this reference version. The release is not the original
> implementation used to obtain the previously reported numerical results, and it
> does not establish reproduction of those results.

A public GitHub URL, Git commit, release tag or archival DOI must be obtained from
an actual publication action. None is invented in this package. The provided archive
is distributed through https://github.com/codeofpaper2026/FATAR-IoT. No archival DOI is claimed.
