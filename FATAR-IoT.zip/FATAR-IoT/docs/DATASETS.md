# Datasets and preprocessing

## What is actually present

This release includes the unchanged UCI RT-IoT2022 CSV, its download/hash manifest,
and the newly generated synthetic dataset and example partitions. The original
manuscript's synthetic experiment is not reconstructed. See RUN_REAL_DATA.md to generate your own RT-IoT2022 experiment outputs. UNSW-NB15 raw data
and experiments are not included.

## Synthetic v1: included and runnable offline

`data/synthetic/synthetic_v1.csv.gz` contains 30,000 examples. `row_id` is a stable
identifier, `x00` through `x19` are numeric features, and `label` is benign=0/attack=1.
These are generic simulated classification features, **not measured network fields**.
The complete generation settings, class counts, library versions and SHA-256 are
in `data/synthetic/manifest.json`.

Generation uses `sklearn.datasets.make_classification` with 20 features, 12 informative,
4 redundant, 2 clusters per class, nominal weights 0.85/0.15, `flip_y=0.02`,
`class_sep=1.0` and generator seed 42. Label noise means observed proportions need
not equal the nominal weights. The raw generator seed is distinct from experiment
seeds; repeated experiments resplit this one fixed dataset.

The included split `data/example_split/` is prepared with experiment seed 42:

| Split | Rows | Benign | Attack | Role |
|---|---:|---:|---:|---|
| Client training | 19,200 | 15,807 | 3,393 | Fit preprocessing and local models |
| Validation | 2,400 | 2,023 | 377 | Logged for diagnosis; no automatic tuning |
| Trust reference | 1,200 | 1,200 | 0 | FATR candidate-drift scoring only |
| Calibration | 1,200 | 1,200 | 0 | Shared method-independent threshold rule |
| Test | 6,000 | 5,058 | 942 | Held-out performance only |

The test counts deliberately do not pretend to equal the original manuscript's
5,077/923 counts. All five splits have disjoint IDs and feature fingerprints.
`dataset.npz` contains `<split>_X`, `<split>_y`, `<split>_ids`, `<split>_groups` and
`feature_names`; load with `numpy.load(..., allow_pickle=False)`. Raw row membership
is also available as `split_ids.csv`.

## RT-IoT2022: official-source downloader and CSV adapter

Custodian/source: UCI Machine Learning Repository, dataset 942.

- Landing page: https://archive.ics.uci.edu/dataset/942/rt-iot2022
- Official archive: https://archive.ics.uci.edu/static/public/942/rt-iot2022.zip
- Dataset DOI: https://doi.org/10.24432/C5P338
- Attribution: S., B. & Nagapadma, R. (2023). *RT-IoT2022* [Dataset]. UCI Machine Learning Repository.
- UCI identifies the license as CC BY 4.0: https://creativecommons.org/licenses/by/4.0/

The source page reports 123,117 examples, with normal IoT traffic and controlled
network-attack patterns. Some descriptive fields on that page are internally
inconsistent, including the feature count and class-count prose. This code therefore
reads actual columns and logs **observed** label counts rather than substituting
webpage totals for the downloaded release. Any previously unrecognized label causes
an error and requires an explicit reviewed mapping update.

```bash
python -m fatr_iot prepare --config configs/rt_iot2022.yaml --seed 42 --output outputs/rt_prepared
python -m fatr_iot run --config configs/rt_iot2022.yaml --output outputs/rt_benchmark
```

When the archive has already been downloaded from UCI:

```bash
python -m fatr_iot fetch rt_iot2022 --archive /path/to/rt-iot2022.zip --output data/raw/rt_iot2022
```

A trusted expected archive hash can be supplied using `--expected-sha256`.
Without it, HTTPS retrieval and a newly recorded hash identify the observed download;
they do not establish equivalence to an independently authenticated previous release.
The downloader never silently guesses an expected hash.

The loader removes `Attack_type` from features and drops `Unnamed:*` export indices.
It recognizes normal-label variants for MQTT/MQTT_Publish, Thing_speak, Wipro_bulb,
and Amazon-Alexa after case/separator normalization. Recognized attack patterns are
DOS_SYN_Hping, ARP_poisioning/ARP_poisoning, NMAP_UDP_SCAN, NMAP_XMAS_TREE_SCAN,
NMAP_OS_DETECTION, NMAP_TCP_scan, DDOS_Slowloris, Metasploit_Brute_Force_SSH and
NMAP_FIN_SCAN. The original textual labels remain in per-category output reports.
Port features `id.orig_p` and `id.resp_p` are retained; the row index is not.
The exact usable feature count and class totals are computed after loading.

CC BY 4.0 attribution is retained in `download_manifest.json`. Copying a CSV without
byte changes and later preprocessing are recorded separately. Any redistributed
original/derived RT-IoT2022 data must retain their attribution and license, not the
MIT code license. The dataset's simulated attack traffic is not equivalent to
longitudinal production IoT telemetry.

## UNSW-NB15: import original custodian CSVs

Official source and usage terms:
https://research.unsw.edu.au/projects/unsw-nb15-dataset

The custodian provides a download link and describes these predefined partitions:
`UNSW_NB15_training-set.csv` (175,341 rows) and
`UNSW_NB15_testing-set.csv` (82,332 rows). Place the two downloaded files under
`data/raw/unsw_nb15/`, retaining their original names. No third-party mirror is
silently used and no files are bundled here.

```bash
python -m fatr_iot prepare --config configs/unsw_nb15.yaml --seed 42 --output outputs/unsw_prepared
python -m fatr_iot run --config configs/unsw_nb15.yaml --output outputs/unsw_benchmark
```

The original `label` is the binary target. `attack_cat` is retained only for category
reporting, and both it and `id` are excluded from predictors. The official test
membership is preserved. Exact feature duplicates are collapsed by keeping the first occurrence, regardless
of label; conflicting-label feature groups are counted for a data-quality audit,
not used to filter training records. This avoids using official test labels to alter
the retained training pool; a row duplicated across official train/test
is kept only in training because that file is processed first. Consequently,
post-cleaning counts can be smaller than the original release. No test row is
reassigned into training.

The official page grants free academic research use and says commercial use needs
agreement from the authors; it requests citation of the listed dataset papers.
Review those terms and cite the required works before redistribution or commercial
use. This repository does **not** relabel UNSW-NB15 as MIT or CC BY.

## Common split and feature pipeline

First, by default, collapse exact feature duplicates by keeping the first occurrence,
without using labels to decide which occurrence survives. Conflicting labels are
reported for data-quality review, not used to change retained training rows. Fingerprints exclude IDs and labels. For synthetic/RT-IoT2022, hold out
20% of retained rows by binary-label stratification; for UNSW-NB15, use the official
test membership. Reserve 10% of the remaining pool for validation, then draw separate
1,200-row benign trust and calibration buffers from the remaining training pool.
Those buffer rows are excluded from client training.

Fit numeric medians, means, scales and categorical vocabularies **only** on the
remaining client-training rows. Nonfinite numeric values become missing, all-missing
numeric columns receive zero, and other numeric missing values receive the training
median. Public-data configurations apply a signed `log1p` numeric transform before
training-only standardization and clip standardized numeric values to [-20,20].
Synthetic defaults use no log transform or scaled clipping. Training categories
are one-hot encoded; unseen values map to all zeros. Numeric standard deviations
use `ddof=0`; constant numeric columns use scale one. No oversampling occurs.

This is a centralized, offline preprocessing simulation on the training population,
not privacy-preserving federated preprocessing. Randomized row splits and exact
feature deduplication do not certify device/session independence or chronological
generalization. Missing session/device metadata prevents such guarantees here.
A benign label in a public dataset is a benchmark assumption, not an operational
procedure for establishing trusted-reference cleanliness.
