# Publish the clean repository to GitHub

The repository is prepared locally; no remote repository has been created or pushed.
The package contains no authentication token, private key, model-service credential,
reviewer correspondence or manuscript PDF. Review source, dataset rights and coauthor/
institutional approval before release. MIT is supplied for the newly authored
material; third-party datasets retain their own terms.

Create an **empty** GitHub repository named, for example, `FATR-IoT`. Do not initialize
it with another README, license or gitignore. Then run the following from the
extracted `fatr-iot` folder. Replace `YOUR_USERNAME` with your real account name:

```bash
git init -b main
git add .
git status --short
git commit -m "Add FATR-IoT reference implementation and synthetic benchmark"
git remote add origin https://github.com/YOUR_USERNAME/FATR-IoT.git
git remote -v
git push -u origin main
```

The placeholder above is a command template, **not** a claimed existing repository.
Authenticate using GitHub's supported credential manager, browser/CLI flow or SSH;
never put a token into a source file, URL committed to the repository or README.
The `.gitignore` excludes `.venv`, caches, unreviewed raw public data and future
`outputs/` runs. It deliberately retains the bundled synthetic data, prepared example
and reviewed validation logs.

Run verification before publishing:

```bash
python -m pytest -q
python scripts/check_release.py
```

After publishing and checking CI, tag an immutable release:

```bash
git tag -a v0.1.0 -m "FATR-IoT reference implementation v0.1.0"
git push origin v0.1.0
```

Check the GitHub Actions run: the included workflow has not yet run on your account.
If desired for a manuscript submission, archive the actual tagged repository using
a repository/archival service and use the **real** release URL or assigned identifier.
Do not put an unissued DOI into the manuscript or `CITATION.cff`.

For publication of raw RT-IoT2022 or UNSW-NB15 data, first review the source license
and attribution rules in `DATASETS.md`; the default repository does not commit them.
The source-only ZIP omits the actual synthetic examples as well; use the full ZIP
for an immediately runnable offline data package, or regenerate the synthetic CSV
before running source-only code.

Official guidance: https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github
