# Run RT-IoT2022 experiments

Install the project and dependencies as described in README.md. The original UCI CSV is bundled with attribution and its download manifest.

```bash
python scripts/check_release.py
python -m fatr_iot run --config configs/rt_iot2022.yaml --output outputs/rt_iot2022 --plots
python scripts/verify_real_data_results.py --input outputs/rt_iot2022
```

The configuration uses six methods, five conditions, five seeds, 20 clients and 30 rounds. Use a new or empty output directory. All metrics, predictions, plots and logs are generated locally. No saved experiment results are distributed.

The model is binary logistic regression. RT-IoT2022 contains testbed traffic with controlled network attacks; random row splits do not establish device/session/time generalization. The implementation is a new reference implementation, not reconstruction of the original synthetic experiment. The geometry_trust comparator must not be relabeled as the original TrustFedAvg.

Dataset: S., B. & Nagapadma, R. (2023). RT-IoT2022 [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5P338. CC BY 4.0: https://creativecommons.org/licenses/by/4.0/. Original CSV bytes are unchanged.
