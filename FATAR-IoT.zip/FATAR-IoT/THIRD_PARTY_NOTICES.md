# Third-party notices

The MIT license at the repository root applies to the newly authored code,
documentation and newly generated synthetic artifacts, not to third-party datasets
or separately installed dependencies. No original paper training implementation,
publisher class file, manuscript PDF, third-party source tree or font file is vendored.

NumPy, SciPy, pandas, scikit-learn, PyYAML, threadpoolctl, matplotlib, pytest and other
installed requirements retain their own licenses. They are installed by the user;
consult the relevant package distributions for their notices.

RT-IoT2022 is separately distributed by its creators through UCI under CC BY 4.0.
Attribution: S., B. & Nagapadma, R. (2023). *RT-IoT2022* [Dataset]. UCI Machine
Learning Repository. https://doi.org/10.24432/C5P338.
License: https://creativecommons.org/licenses/by/4.0/.
This update bundles the original RT-IoT2022 CSV, copied byte-for-byte from the official
UCI archive, alongside the downloader and adapter. The observations remain under
CC BY 4.0; the MIT code license does not apply to them. Preprocessing and experimental
results are documented derivatives; the source CSV itself is unchanged.
The downloader writes attribution and SHA-256 information into its download manifest.

UNSW-NB15 remains subject to the custodian's terms. The official source grants free
academic research use, requires citation and calls for agreement for commercial use.
No permission to distribute the original data under the code's MIT license is implied.
Source: https://research.unsw.edu.au/projects/unsw-nb15-dataset.
No UNSW-NB15 observations are included in this package.

The small public-schema fixtures in the test suite are invented test records and
are not samples downloaded from either public dataset.
