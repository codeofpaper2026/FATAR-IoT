# Scope, security and responsible use

This software simulates model-update and label poisoning **offline** for defensive
federated-learning research. It contains no packet sender, scanner, exploit payload,
live network attack or automated action against an operational service.

The only network operation is an explicit user-invoked HTTPS download from UCI.
Training and inference do not transmit data or metrics. Models are saved as numeric
NPZ arrays loaded with `allow_pickle=False`; preprocessing metadata is plain JSON.
Archive members are copied to a fixed local CSV filename rather than extracted
using untrusted paths. Download sizes are bounded, errors are explicit and optional
expected hashes are verified before processing.

The simulated coordinator sees individual updates and persistent client IDs. Its
benign reference is assumed clean. Client counts are trusted simulator metadata.
There is no secure aggregation, differential privacy, encrypted computation, network
enrollment, sybil defense, reference authentication, secure device telemetry,
malicious-size-claim defense, or protection against a compromised server.
The poisoning conditions do not cover adaptive/backdoor attacks or slow history
contamination. All clients participate; churn/reset semantics are not implemented.

A low trust score is not a diagnosis of malicious intent. Legitimate heterogeneous
clients can be downweighted. Benign signed-mean drift can hide cancellation and is
not a certified constraint on attack recall or false-positive-rate tails. Training
preprocessing is centralized on the allowed training population for simulation.

Do not deploy the demonstration classifier as a security control without independent
validation, dataset-governance review, privacy assessment, monitoring, rollback
procedures and appropriate human oversight. Do not commit live traffic, private
client identities, credentials or secret-bearing logs to a public repository.

For a vulnerability in a published repository, use that repository's private
security-reporting channel when configured. This local package has no claimed
public issue tracker or contact address.
